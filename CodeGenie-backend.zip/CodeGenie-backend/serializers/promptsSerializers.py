def promptEntity(prompt) -> dict:
    _id = str(prompt["_id"])
    del prompt["_id"]
    prompt["_id"] = _id

    if "product_id" in prompt:
        _product_id = str(prompt["product_id"])
        del prompt["product_id"]
        prompt["product_id"] = _product_id
    else:
        prompt["product_id"] = ""

    return prompt



def promptsEntity(prompts):
    return [promptEntity(prompt) for prompt in prompts]
