def blogEntity(blog) -> dict:
    _id = str(blog["_id"])
    del blog["_id"]
    blog["_id"] = _id

    if "product_id" in blog:
        _product_id = str(blog["product_id"])
        del blog["product_id"]
        blog["product_id"] = _product_id
    else:
        blog["product_id"] = ""

    if "prompt_id" in blog:
        _prompt_id = str(blog["prompt_id"])
        del blog["prompt_id"]
        blog["prompt_id"] = _prompt_id
    else:
        blog["prompt_id"] = ""

    return blog


def blogsEntity(blogs):
    return [blogEntity(blog) for blog in blogs]
