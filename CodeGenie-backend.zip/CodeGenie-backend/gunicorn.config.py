workers = 3
timeout = 360  # Set the timeout to 6 minutes (360 seconds)