from typing import List
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
from pydantic import EmailStr, BaseModel
from config import settings
from jinja2 import Environment, select_autoescape, PackageLoader


env = Environment(
    loader=PackageLoader("templates", ""),
    autoescape=select_autoescape(["html"]),
)


class EmailSchema(BaseModel):
    email: List[EmailStr]


class VerifyEmail:
    def __init__(self, name: str, code: str, email: List[EmailStr]):
        self.name = name
        self.email = email
        self.code = code
        pass

    async def sendMail(self, subject, template):
        # Define the config
        conf = ConnectionConfig(
            MAIL_USERNAME=settings.EMAIL_USERNAME,
            MAIL_PASSWORD=settings.EMAIL_PASSWORD,
            MAIL_FROM=settings.EMAIL_FROM,
            MAIL_PORT=settings.EMAIL_PORT,
            MAIL_SERVER=settings.EMAIL_HOST,
            MAIL_STARTTLS=True,
            MAIL_SSL_TLS=False,
        )
        # Generate the HTML template base on the template name
        template = env.get_template(f"{template}.html")

        html = template.render(code=self.code, first_name=self.name, subject=subject)

        # Define the message options
        message = MessageSchema(
            subject=subject, recipients=self.email, body=html, subtype="html"
        )

        # Send the email
        fm = FastMail(conf)
        await fm.send_message(message)

    async def sendVerificationCode(self):
        await self.sendMail("Welcome to Code Genie! Please Verify Your Email 🧞‍♂️", "verification")

class ForgotPassEmail:
    def __init__(self, name: str, code: str, email: List[EmailStr]):
        self.name = name
        self.email = email
        self.code = code
        pass

    async def sendMail(self, subject, template):
        # Define the config
        conf = ConnectionConfig(
            MAIL_USERNAME=settings.EMAIL_USERNAME,
            MAIL_PASSWORD=settings.EMAIL_PASSWORD,
            MAIL_FROM=settings.EMAIL_FROM,
            MAIL_PORT=settings.EMAIL_PORT,
            MAIL_SERVER=settings.EMAIL_HOST,
            MAIL_STARTTLS=True,
            MAIL_SSL_TLS=False,
        )
        # Generate the HTML template base on the template name
        template = env.get_template(f"{template}.html")

        html = template.render(code=self.code, first_name=self.name, subject=subject)

        # Define the message options
        message = MessageSchema(
            subject=subject, recipients=self.email, body=html, subtype="html"
        )

        # Send the email
        fm = FastMail(conf)
        await fm.send_message(message)

    async def sendVerificationCode(self):
        await self.sendMail("Password Reset Confirmation", "forgotPass")


class Feedbackemail:
    def __init__(self, email: int, rating: str, feedback: str, productname: str=""):
        self.email = email
        self.rating = rating
        self.feedback = feedback
        self.productname = productname
        pass

    async def sendMail(self, subject, template):
        # Define the config
        conf = ConnectionConfig(
            MAIL_USERNAME=settings.EMAIL_USERNAME,
            MAIL_PASSWORD=settings.EMAIL_PASSWORD,
            MAIL_FROM=settings.EMAIL_FROM,
            MAIL_PORT=settings.EMAIL_PORT,
            MAIL_SERVER=settings.EMAIL_HOST,
            MAIL_STARTTLS=True,
            MAIL_SSL_TLS=False,
        )
        # Generate the HTML template base on the template name
        template = env.get_template(f"{template}.html")

        html = template.render(email=self.email, rating=self.rating, feedback=self.feedback, productname=self.productname)

        # Define the message options
        message = MessageSchema(
            subject=subject, recipients=["support@code-genie.ai","balaksara@gmail.com"], body=html, subtype="html"
        )

        # Send the email
        fm = FastMail(conf)
        await fm.send_message(message)

    async def sendFeedback(self):
        await self.sendMail("User Feedback", "feedback")
class ResendVerificationEmail:
    def __init__(self, name: str, token: str, email: List[EmailStr]):
        self.name = name
        self.email = email
        self.token = token
        pass

    async def sendMail(self, subject, template):
        # Define the config
        conf = ConnectionConfig(
            MAIL_USERNAME=settings.EMAIL_USERNAME,
            MAIL_PASSWORD=settings.EMAIL_PASSWORD,
            MAIL_FROM=settings.EMAIL_FROM,
            MAIL_PORT=settings.EMAIL_PORT,
            MAIL_SERVER=settings.EMAIL_HOST,
            MAIL_STARTTLS=True,
            MAIL_SSL_TLS=False,
        )
        # Generate the HTML template base on the template name
        template = env.get_template(f"{template}.html")

        html = template.render(token=self.token, first_name=self.name, subject=subject)

        # Define the message options
        message = MessageSchema(
            subject=subject, recipients=self.email, body=html, subtype="html"
        )

        # Send the email
        fm = FastMail(conf)
        await fm.send_message(message)

    async def sendVerificationCode(self):
        await self.sendMail("New Verification Code", "resendVerification")

        
class Contactus:
    def __init__(self, name: str, email: str, phone: str, subject: str, message: str):
        self.name = name
        self.email = email
        self.phone = phone
        self.subject = subject
        self.message = message
        pass

    

    async def sendMail(self, subject, template):
        print("-----------",self.email)
        # Define the config
        conf = ConnectionConfig(
            MAIL_USERNAME=settings.EMAIL_USERNAME,
            MAIL_PASSWORD=settings.EMAIL_PASSWORD,
            MAIL_FROM=settings.EMAIL_FROM,
            MAIL_PORT=settings.EMAIL_PORT,
            MAIL_SERVER=settings.EMAIL_HOST,
            MAIL_STARTTLS=True,
            MAIL_SSL_TLS=False,
        )
        # Generate the HTML template base on the template name
        template = env.get_template(f"{template}.html")

        html = template.render(subject=subject, username=self.name, name=self.name, email=self.email, contact=self.phone, message=self.message)

        print(html)

        # Define the message options
        message = MessageSchema(
            subject=subject, recipients=["support@code-genie.ai","balaksara@gmail.com"], body=html, subtype="html"
        )

        # Send the email
        fm = FastMail(conf)
        await fm.send_message(message)

    async def sendFeedback(self):
        await self.sendMail("Contact Us", "contactus")
