from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, constr


class SocialSignupSchema(BaseModel):
    provider: str
    email: EmailStr | None = None
    username: str | None = None
    name: str
    id: str
    initial_product: str | None = None


class UserSignupSchema(BaseModel):
    name: str
    email: EmailStr
    password: constr(min_length=8)
    passwordConfirm: str
    initial_product: str | None = None


class UserSigninSchema(BaseModel):
    email: EmailStr
    password: constr(min_length=8)

class ForgotPasswordSchema(BaseModel):
    email: EmailStr

class ResetPasswordSchema(BaseModel):
    email: EmailStr
    password: constr(min_length=8)
    passwordConfirm: str

class UpdatePasswordSchema(BaseModel):
    email: EmailStr
    oldPassword: str
    password: constr(min_length=8)
    passwordConfirm: str

class PriceIdSchema(BaseModel):
    price_id: str

class FeebackSchema(BaseModel):
    email: EmailStr
    rating: int
    feedback: str
    productname: str
    date:  Optional[datetime]

class ContactUsSchema(BaseModel):
    name: str
    email: EmailStr
    phone: str
    subject: str
    message: str

class SubscribeSchema(BaseModel):
    email: EmailStr
    status: str
    created_at: str | None = None
    updated_at: str | None = None