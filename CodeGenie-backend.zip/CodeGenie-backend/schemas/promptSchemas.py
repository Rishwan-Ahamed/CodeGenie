from pydantic import BaseModel


class PromptBaseSchema(BaseModel):
    product: str
    plan: str
    module: str
    prompt_name: str
    order: int
    prompt: str


class RunPromptSchema(BaseModel):
    product_name: str
    product_module: str
    code: str
    email: str
    free_plan: int
    subscription_level: str

class BlogSummarySchema(BaseModel):
    id: str
    blog_title: str
    blog_image: str
    blog_summary: str
    blog_det: str
    url: str

