from urllib import request
from fastapi import APIRouter, HTTPException, status, Response, Depends, Body
from datetime import datetime, timedelta
from random import randbytes
import hashlib
from typing import Annotated
import stripe
from bson import json_util  # Import bson's json_util

from schemas.userSchemas import SocialSignupSchema, UserSignupSchema, UserSigninSchema, ForgotPasswordSchema, ResetPasswordSchema
from database import Users, Payment
import utils
from emails.verifyEmail import VerifyEmail, ForgotPassEmail
from oauth2 import AuthJWT, require_user
from config import settings
from database import Products
from dateutil.relativedelta import relativedelta
from datetime import datetime

router = APIRouter()

# Replace with your Stripe secret key
stripe.api_key = settings.STRIPE_SECRET_KEY

ACCESS_TOKEN_EXPIRES_IN = settings.ACCESS_TOKEN_EXPIRES_IN
REFRESH_TOKEN_EXPIRES_IN = settings.REFRESH_TOKEN_EXPIRES_IN

@router.get("/config")
async def config():
    return {"publishableKey": settings.STRIPE_API_KEY}

@router.get("/create-payment-intent")
async def create_payment_intent(amount: float, currency: str):
    try:
        payment_intent = stripe.PaymentIntent.create(
            amount = round(amount),
            currency= currency,
        )
        return {"status": "success", "client_secret": payment_intent.client_secret}
    except stripe.error.StripeError as e:
        return {"status": "error", "client_secret": e.user_message}, 400
    except Exception as e:
        return {"status": "error", "client_secret": e.user_message}, 500
    

@router.post("/payment-update/")
async def process_payment(amount: float, currency: str, email: str):
    if email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": email})
    print(existing)
    if existing:
        try:            
            Payment.insert_one({
                "email": email,
                "amount": round(amount),
                "currency": currency,
                "created_at": datetime.utcnow(),
                "status": "success"
            })
        except Exception as error:
            print(error)
            Payment.insert_one({
                "email": email,
                "amount": round(amount),
                "currency": currency,
                "created_at": datetime.utcnow(),
                "status": "failed"
            })
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in payment update",
            )
    return {
        "status": "success",
        "message": "Pament updated successfully",
    }


@router.post("/update_wish_count/")
async def process_payment(email: str):
    if email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": email})
    #print(existing)
    if existing:
        try: 
            #check existing count is 0 or less then just update instead of increment
            remainingcount = existing['remaining_wish_count']
            # Specify the update operation using $inc
            update = {"$inc": {"wish_count":1}}  # Increment by 5
            Users.find_one_and_update(
                {"email": existing['email']},
                update
            )
        except Exception as error:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in payment update",
            )
    return {
        "status": "success",
        "message": "Wishcount incremeneted",
    }

@router.post("/get_remaining_wish_count/")
async def process_payment(email: str):
    if email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": email}) #get user current plan
    #print(existing)
    if existing:
        try: 
            # sepcify the query to get total wishes of that paln
            query = {
                "product_module": existing['product_module'],                 # Match the parent document
                "plan_details": {"$elemMatch": {"price_id": existing['price_id']}}  # Match the subdocument field
            }
            products = Products.find_one(
                query, {"plan_details.$": 1}
            )
            
            #calculate remaining wish count
            total_wishes = int(products['plan_details'][0]['total_wishes'])
            remaining_count = total_wishes - existing['wish_count']

        except Exception as error:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in payment update",
            )
            
    return {
        "status": "success",
        "message": "Wishcount incremeneted",
        "remaining_count": remaining_count
    }


@router.post("/get_payment_list/")
async def process_payment(email: str, skip: int = 0, limit: int = 10):
    if email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": email}) #get user current plan

    payments = []
    recordcount = 0
    #print(existing)
    if existing:
        try: 
            # get the stripe customer id
            stripe_cust_id = existing['stripe_cust_id']

            #if stripe customer id not null or emtpy then get payment details
            query = {
                "stripe_cust_id": stripe_cust_id
            }

            if len(stripe_cust_id.strip()) > 0:
                payments = list(Payment.find(
                    query, {"_id": 0}
                ).sort("payment_date",-1).skip(skip).limit(limit))

                recordcount = Payment.count_documents(query)
            
              # Convert MongoDB documents to JSON-serializable format
            payments = list(payments)


            print(payments)
                

        except Exception as error:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in payment listing",
            )
            
    return {
        "status": "success",
        "message": "Payment list returned successfully",
        "payments":  payments,
        "totalrecords": recordcount
    }


@router.post("/get_total_users/")
async def total_users(from_date: str, to_date: str, mode: str="This Week", product: str=""):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")

    filter = {"$and": [{"created_at": {"$gte": fromDate, "$lte":toDate},"role":"user"}]}
    if(product!=""):
        extrafilter = {"$or":[{"product_module":product},{"initial_product":product}]}
        filter["$and"].append(extrafilter)

    recordcount = Users.count_documents(filter) #get user current plan

    return{
        "status":"success",
        "message": "Record count returned successfully",
        "totalrecords": recordcount
    }

@router.post("/get_total_count_users/")
async def total_count_users():
    recordcount = Users.count_documents({"role":"user"}) #get user current plan

    return{
        "status":"success",
        "message": "Record count returned successfully",
        "totalrecords": recordcount
    }


@router.post("/get_total_revenue_sum/")
async def total_revenue_sum():

    # Define the aggregation pipeline
    pipeline = [
        {
            "$match": {}  # Use $match to filter documents
        },
        {
            "$group": {
                "_id": None,  # Group by all documents (no grouping)
                "total": {"$sum": "$amount"}  # Calculate the sum of the field
            }
        }
    ]

    record = list(Payment.aggregate(pipeline)) #get user current plan
  
    value = 0
    if len(record)>0:
        value =  round(record[0]["total"]/100,2)
        value = '{:,.2f}'.format(value)

    return{
        "status":"success",
        "message": "Total returned successfully",
        "total_revenue_sum": value
    }


@router.post("/get_total_users_increase_percent/")
async def total_users_increase_precentage(from_date: str, to_date: str, mode: str="This Week", product: str=""):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")

    filter = {"$and": [{"created_at": {"$gte": fromDate, "$lte":toDate},"role":"user"}]}
    if(product!=""):
        extrafilter = {"$or":[{"product_module":product},{"initial_product":product}]}
        filter["$and"].append(extrafilter)

    recordcount = Users.count_documents(filter) #get user current plan

    value =  round(recordcount/100,2)
    value = '{:,.2f}'.format(value)

    return{
        "status":"success",
        "message": "Record count returned successfully",
        "user_increase_percentage": value
    }


@router.post("/get_total_revenue/")
async def total_revenue(from_date: str, to_date: str, mode: str="This Week", product: str=""):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")

    # Define the aggregation pipeline
    pipeline = [
        {
            "$match": {"payment_date": {"$gte": fromDate, "$lte":toDate}}  # Use $match to filter documents
        },
        {
            "$group": {
                "_id": None,  # Group by all documents (no grouping)
                "total": {"$sum": "$amount"}  # Calculate the sum of the field
            }
        }
    ]

    record = list(Payment.aggregate(pipeline)) #get user current plan
  
    value = 0
    if len(record)>0:
        value =  round(record[0]["total"]/100,2)
        value = '{:,.2f}'.format(value)

    return{
        "status":"success",
        "message": "Total returned successfully",
        "total_revenue": value
    }


@router.post("/get_total_revenue_increase_percent/")
async def total_revenue_increase_percent(from_date: str, to_date: str, mode: str="This Week", product: str=""):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")

    print("mode:::",mode)

    # Define the aggregation pipeline
    pipeline = [
        {
            "$match": {"payment_date": {"$gte": fromDate, "$lte":toDate}}  # Use $match to filter documents
        },
        {
            "$group": {
                "_id": None,  # Group by all documents (no grouping)
                "total": {"$sum": "$amount"}  # Calculate the sum of the field
            }
        }
    ]

    record = list(Payment.aggregate(pipeline)) #get user current plan

    print(pipeline)

    print(record)

    value = 0
    valuefloat = 0
    if len(record)>0:
        valuefloat =  round(record[0]["total"]/100,2)
        value = '{:,.2f}'.format(valuefloat)

    # Convert the string to a date
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    # Calculate the previous date by subtracting one year
    previous_date = fromDate 
    previous_to_date = fromDate + timedelta(days=365)
    
    # Format the previous date as a string
    previous_date_str = previous_date.strftime("%Y-%m-%d")
    previous_to_date_str = previous_to_date.strftime("%Y-%m-%d")
    previous_date = datetime.strptime(previous_date_str, "%Y-%m-%d")
    previous_to_date = datetime.strptime(previous_to_date_str, "%Y-%m-%d")


    #get previous data
    valuePrev = 0
    valuePrevFloat = 0
    if mode=="previous_period":
        # Calculate the previous date by subtracting one day
        previous_date = fromDate 
        previous_from_date = fromDate - timedelta(days=1)
        
        # Format the previous date as a string
        previous_date_str = previous_date.strftime("%Y-%m-%d")
        previous_from_date_str = previous_from_date.strftime("%Y-%m-%d")
        previous_date = datetime.strptime(previous_date_str, "%Y-%m-%d")
        previous_from_date = datetime.strptime(previous_from_date_str, "%Y-%m-%d")

    if mode=="previous_month":
        # Calculate the previous date by subtracting one month
        previous_date = fromDate 

        # Extract the year
        newDate = fromDate - relativedelta(months=1)
        month = newDate.month
        year = newDate.year

        toMonth = fromDate.month
        toYear = fromDate.year

        # Convert the string to a date
        fromDate = datetime.strptime(str(year)+"-"+str(month)+"-01", '%Y-%m-%d')
        
        # Calculate the previous date by subtracting one year
        previous_date = fromDate 
        previous_to_date = datetime.strptime(str(toYear)+"-"+str(toMonth)+"-01", '%Y-%m-%d')
        
        # Format the previous date as a string
        previous_date_str = previous_date.strftime("%Y-%m-%d")
        previous_to_date_str = previous_to_date.strftime("%Y-%m-%d")
        previous_date = datetime.strptime(previous_date_str, "%Y-%m-%d")
        previous_to_date = datetime.strptime(previous_to_date_str, "%Y-%m-%d")

    if mode=="previous_week":
         # Calculate the previous date by subtracting one week
        previous_date = fromDate - relativedelta(days=7) 
        previous_to_date = fromDate
        
        # Format the previous date as a string
        previous_date_str = previous_date.strftime("%Y-%m-%d")
        previous_to_date_str = previous_to_date.strftime("%Y-%m-%d")
        previous_date = datetime.strptime(previous_date_str, "%Y-%m-%d")
        previous_to_date = datetime.strptime(previous_to_date_str, "%Y-%m-%d")

    if mode=="previous_year":

        # Extract the year
        year = fromDate.year-1

        # Convert the string to a date
        fromDate = datetime.strptime(str(year)+"-01-01", '%Y-%m-%d')
        
        # Calculate the previous date by subtracting one year
        previous_date = fromDate 
        previous_to_date = fromDate + timedelta(days=365)
        
        # Format the previous date as a string
        previous_date_str = previous_date.strftime("%Y-%m-%d")
        previous_to_date_str = previous_to_date.strftime("%Y-%m-%d")
        previous_date = datetime.strptime(previous_date_str, "%Y-%m-%d")
        previous_to_date = datetime.strptime(previous_to_date_str, "%Y-%m-%d")


    print("previous_date_str::",previous_date_str)
    # Define the aggregation pipeline
    pipeline1 = [
        {
            "$match": {"payment_date": {"$gte": previous_date, "$lte": previous_to_date}}  # Use $match to filter documents
        },
        {
            "$group": {
                "_id": None,  # Group by all documents (no grouping)
                "total": {"$sum": "$amount"}  # Calculate the sum of the field
            }
        }
    ]

    record1 = list(Payment.aggregate(pipeline1)) #get user current plan

    print(pipeline1)

    print(record1)

    if len(record1)>0:
        valuePrevFloat =  round(record1[0]["total"]/100,2)
        valuePrev = '{:,.2f}'.format(valuePrevFloat)
   
    perval = 0
    if valuefloat > 0:
        perval = (valuePrevFloat / valuefloat)*100

    if valuePrevFloat <= 0:
        perval = 100

    print("valuePrevFloat::",valuePrevFloat)
    print("preval::",perval)

    perval = '{:,.2f}'.format(perval)  
    

    return{
        "status":"success",
        "message": "Record count returned successfully",
        "revenue_increase_percent": perval
    }


@router.post("/get_total_google_visit/")
async def total_revenue_increase_percent(from_date: str, to_date: str, mode: str="This Week", product: str=""):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")

    # Define the aggregation pipeline
    pipeline = [
        {
            "$match": {"payment_date": {"$gte": fromDate, "$lte":toDate}}  # Use $match to filter documents
        },
        {
            "$group": {
                "_id": None,  # Group by all documents documents (no grouping)
                "total": {"$sum": "$amount"}  # Calculate the sum of the field
            }
        }
    ]

    record = list(Payment.aggregate(pipeline)) #get user current plan

    return{
        "status":"success",
        "message": "Record count returned successfully",
        "total_google_visit": 10
    }

@router.post("/get_total_google_visit_increase_percentage_visit/")
async def total_revenue_increase_percent(from_date: str, to_date: str, mode: str="This Week", product: str=""):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")

    # Define the aggregation pipeline
    pipeline = [
        {
            "$match": {"payment_date": {"$gte": fromDate, "$lte":toDate}}  # Use $match to filter documents
        },
        {
            "$group": {
                "_id": None,  # Group by all documents (no grouping)
                "total": {"$sum": "$amount"}  # Calculate the sum of the field
            }
        }
    ]

    record = list(Payment.aggregate(pipeline)) #get user current plan



    return{
        "status":"success",
        "message": "Record count returned successfully",
        "total_google_visit_increment_percent": 5
    }


@router.post("/get_users_data_for_chart_between_date_range/")
async def total_users(from_date: str, to_date: str):
    fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    toDate = datetime.strptime(to_date, "%Y-%m-%d")


    # Define the aggregation pipeline
    pipeline = [
        {
            "$match": {
                "created_at": {
                    "$gte": fromDate,
                    "$lte": toDate
                },
                "role":"user"
            }
        },
        {
            "$group": {
                "_id": {
                    "year": {"$year": "$created_at"},
                    "month": {"$month": "$created_at"},
                    "day": {"$dayOfMonth": "$created_at"}
                },
                "count": {"$sum": 1}
            }
        }
    ]

    print(pipeline)

    records = list(Users.aggregate(pipeline))

    return{
        "status":"success",
        "message": "User registered count details for date range",
        "totalrecords": records
    }


@router.post("/unsubscribepayment/")
async def plan_unsubscribe(email: str):
     
    
    return{
        "status":"success",
        "message": "Plan unsubscription successfull. It  ewill take effect at the time plan cycle expires.",
    }