from contextlib import _RedirectStream
from os import abort
from urllib import request
import uuid
from fastapi import APIRouter, HTTPException, Request, status, Response, Depends, Body
from datetime import datetime, timedelta
from random import randbytes
import hashlib
from typing import Annotated
import stripe
import logging

from schemas.userSchemas import PriceIdSchema
from database import Users, Payment, Products, Addon
import utils
from emails.verifyEmail import VerifyEmail, ForgotPassEmail
from oauth2 import AuthJWT, require_user
from config import settings
from fastapi import responses
from flask import Flask, request, jsonify
import json


router = APIRouter()

# Replace with your Stripe secret key
stripe.api_key = settings.STRIPE_SECRET_KEY

logging.basicConfig(filename="log.txt", level=logging.DEBUG, format="%(asctime)s %(message)s")

ACCESS_TOKEN_EXPIRES_IN = settings.ACCESS_TOKEN_EXPIRES_IN
REFRESH_TOKEN_EXPIRES_IN = settings.REFRESH_TOKEN_EXPIRES_IN

@router.get("/config")
async def config():
    return {"publishableKey": settings.STRIPE_API_KEY}

@router.get("/create-subscription")
async def create_payment_intent(email: str, stripeToken: str, price_id: str):
    try:
        customer = stripe.Customer.create({
            "email": email,
            "source": stripeToken,
        })
        # Create the subscription. Note we're expanding the Subscription's
        # latest invoice and that invoice's payment_intent
        # so we can pass it to the front end to confirm the payment
        subscription = stripe.Subscription.create(
            customer=customer.id,
            items=[{
                'price': price_id,
            }],
            payment_behavior='default_incomplete',
            payment_settings={'save_default_payment_method': 'on_subscription'},
            expand=['latest_invoice.payment_intent'],
        )
        return {"subscriptionId":subscription.id, "clientSecret":subscription.latest_invoice.payment_intent.client_secret}

    except Exception as e:
        return {"error":{'message': e.user_message}}, 400
    #try:
    #    customer = stripe.Customer.create({
    #        "email": email,
    #        "source": stripeToken,
    #    })
    #    subscription = await stripe.Subscription.create({
    #        "customer": customer.id,
    #        "items": [{ "price": price_id }],
    #    })
    #    print(subscription)
    #    return { subscription }
    #except stripe.error.StripeError as e:
    #    return {"status": "error", "message": e.user_message}, 400
    #except Exception as e:
    #    return {"status": "error", "message": e.user_message}, 500
    

@router.post("/payment-update/")
async def process_payment(amount: float, currency: str, email: str):
    if email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": email})
    print(existing)
    if existing:
        try:            
            Payment.insert_one({
                "email": email,
                "amount": round(amount),
                "currency": currency,
                "created_at": datetime.utcnow(),
                "status": "success"
            })
        except Exception as error:
            print(error)
            Payment.insert_one({
                "email": email,
                "amount": round(amount),
                "currency": currency,
                "created_at": datetime.utcnow(),
                "status": "failed"
            })
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in payment update",
            )
    return {
        "status": "success",
        "message": "Pament updated successfully",
    }

YOUR_DOMAIN = settings.CLIENT_ORIGIN
@router.post('/create-checkout-session')
#def create_checkout_session(payload: PriceIdSchema, response: Response):
def create_checkout_session(emailid: str, username: str, subscription_level: str, referral_param: str=None):
    try: 
        price_id = ""
        product_id = ""
        unit_amount = ""
        product_module = ""
        type= ""
        total_wishes=0
        desc = ""

        pipeline = [
            {"$unwind": "$plan_details"},
            { "$match" : {'plan_details.subscription_level':subscription_level }},
            { "$project" : { "_id":1,
                             "subscription_level" : '$plan_details.subscription_level',
                             "total_wishes" : '$plan_details.total_wishes',
                             "price" : '$plan_details.price',
                             "period" : '$plan_details.period',
                             "product_id" : '$plan_details.product_id',
                             "price_id" : '$plan_details.price_id',
                             "type" : '$plan_details.type',
                             "plan_name" : '$plan_details.plan_name',
                             "product_name" : 1,
                             "product_module" : 1,
                            }
            }            
        ]
        products = Products.aggregate(pipeline)
        for product in products:
            #print(product["subscription_level"])
            price_id = product["price_id"]
            product_id = product["product_id"]
            unit_amount = product["price"]
            product_module = product["product_module"]
            type= product["type"]
            total_wishes= product["total_wishes"]
            desc = "user creater for stripe product: "+product["product_name"]+" module: "+product["product_module"]
        
        # List all customers        
        customers = stripe.Customer.list(email=emailid)
        customerid = ""

        for customerdet in customers.auto_paging_iter():
            #print("Matching Customer:", customerdet)
            customerid = customerdet.id
            
        #if customer id not exists in stripe, then create it
        if customerid == "":
            customerdet = stripe.Customer.create(
                email=emailid,
                name=username,
                description=desc  
                )
            
        customerid = customerdet.id
        #update stripe customer id in user
        Users.find_one_and_update(
            {"email": emailid},
            {
                "$set": {
                    "stripe_cust_id": customerdet.id,
                    "updated_at": datetime.utcnow() ,
                    "new_price_id":price_id,
                    "new_subscription_level": subscription_level,
                    "new_product_module": product_module
                }
            }
        )  

        # Set the client_reference_id

        client_reference_id = ""

        if referral_param:
            client_reference_id = referral_param
        else:
            client_reference_id = f"checkout-{uuid.uuid4()}"

        siteName = 'CodeGenie - www.code-genie.ai'

        mode='subscription'
        line_items={}

        print(subscription_level)
        print(type)
        if type == "subscription":
            mode='subscription'
            line_items={
                # Provide the exact Price ID (for example, pr_1234) of the product you want to sell
                'price': price_id,
                'quantity': 1,
            }
        
        if type == "onetime":
            mode='payment'
            line_items={
                # Provide the exact Price ID (for example, pr_1234) of the product you want to sell
                'price': price_id,
                'quantity': 1,
            }

        
        if type == "addon":
            mode="payment"
            line_items = {
                'price_data': {
                'unit_amount': unit_amount * 100,  # Convert to cents
                'currency': 'usd',  # Change to your desired currency
                'product': product_id,  # Replace with your product ID
            },
            'quantity': total_wishes,
            }
        
        module = product_module.lower().replace(" ", "_")
        checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[
                    line_items,
                ],

                customer=customerid,
                mode=mode,
                success_url=YOUR_DOMAIN + '/success?module='+module+'&subscription_level='+subscription_level+'&session_id={CHECKOUT_SESSION_ID}',
                cancel_url=YOUR_DOMAIN + '/codegenie/'+module+'?canceled=true',
                client_reference_id=client_reference_id,
                metadata={
                    'customer': customerid,
                    'email': emailid,
                    'site_name': siteName,
                    'subscription_level': subscription_level, 
                    'total_wishes': total_wishes, 
                    'remaining_wish_count':total_wishes
                }
            )

        return {"message":"Checkout url created","checkout_url":checkout_session.url}
    except Exception as e:
        print(e)
        return {"message":"Checkout url failed","error":str(e)}

@router.get('/order/success')
def order_success(session_id: str):
    session = stripe.checkout.Session.retrieve(session_id)
    #print(session)
    customer = stripe.Customer.retrieve(session.customer)
    stripe_cust_id = customer.id
    amount=round((session.amount_total/100),2)
    payment_status=session.payment_status
    try:
        existing = Users.find_one({"stripe_cust_id": stripe_cust_id,"new_subscription_level":{"$ne":""}})
        #print(existing)
        if existing:
            try:
                date_updated = datetime.utcnow()

                Payment.insert_one({
                    "user_id": customer.email,
                    "stripe_cust_id": stripe_cust_id,
                    "amount": amount,
                    "invoice_no": session.invoice,
                    "payment_status": payment_status,
                    "payment_date": date_updated,
                    "subscription_level": existing['new_subscription_level']
                })

                subscription_level = existing['new_subscription_level']
                #product_module = existing['new_product_module']
                #price_id = existing['new_price_id']

                logging.info("Inside success pages::::"+"\r\n")
                logging.info("stripe_cust_id:"+stripe_cust_id+"\r\n") 
                logging.info("amount:")  
                logging.info(str(amount))
                logging.info("\r\n")
                logging.info("subscription_level::"+subscription_level+"\r\n")
                logging.info("\r\n") 

                price_id = ""
                product_id = ""
                unit_amount = ""
                product_module = ""
                type= ""
                total_wishes=0

                pipeline = [
                    {"$unwind": "$plan_details"},
                    { "$match" : {'plan_details.subscription_level':subscription_level }},
                    { "$project" : { "_id":1,
                                    "subscription_level" : '$plan_details.subscription_level',
                                    "total_wishes" : '$plan_details.total_wishes',
                                    "price" : '$plan_details.price',
                                    "period" : '$plan_details.period',
                                    "product_id" : '$plan_details.product_id',
                                    "price_id" : '$plan_details.price_id',
                                    "type" : '$plan_details.type',
                                    "plan_name" : '$plan_details.plan_name',
                                    "product_name" : 1,
                                    "product_module" : 1,
                                    }
                    }            
                ]
                products = Products.aggregate(pipeline)
                for product in products:
                    #print(product["subscription_level"])
                    price_id = product["price_id"]
                    product_id = product["product_id"]
                    unit_amount = product["price"]
                    product_module = product["product_module"]
                    type= product["type"]
                    total_wishes= product["total_wishes"]

                #update current plan details
                if type!="addon" and product_module=="Any Code":
                    Users.find_one_and_update(
                        {"email": existing['email']},
                        {"$set": {"stripe_cust_id": stripe_cust_id, "status":"active", 
                                "subscription_date":date_updated,"payment_status": session.payment_status,
                                "subscription_level": subscription_level, "product_module": product_module,
                                "price_id": price_id,"new_subscription_level":"","new_product_module":"","new_price_id":"",
                                "free_plan": 0
                                }},
                    )
    
                #get the details of plan and update contract count

                contractcount = 0

                if type == "addon":
                    oamount = unit_amount
                    contractcount = amount/oamount
                    print(contractcount)
                elif product_module == "Any Code":
                    contractcount = total_wishes

                #print("wish count update----")
                #print(contractcount)
                print("product_module::"+product_module)
                #update contract count 
                if product_module == "Any Code":
                    Users.find_one_and_update(
                        {"email": existing['email']},
                        {
                            "$set":{
                                "total_wishes": contractcount,
                                "remaining_wish_count": contractcount
                            }
                            
                        }
                    )  

            except Exception as error:
                print(error)
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="There was an error in payment update",
                )
    except Exception as e:
        return {"message":"Payment update failed","error":str(e)}
    return {"message": customer}

@router.post('/webhook')
async def webhook(request: Request):
    payload = await request.body()  # Read the request body

    doprocess =  0
    stripe_cust_id = ""
    invoice_no = ""
    ramount = 0

    logging.info("inside webhook **********************\r\n")

    if payload:
        jsondata = json.loads(payload)
    #print("payment intent")
        logging.info(jsondata)
    
        if jsondata.get('payment_status'):
            if jsondata['payment_status'] == "paid":
                doprocess = 1
        elif jsondata.get('type'):
            if jsondata['type'] == "payment_intent.succeeded":
                doprocess = 1
        elif jsondata.get('type'):
            if jsondata['type'] == "invoice.payment_succeeded":
                doprocess = 1

    
    if(doprocess==1):
        #print(jsondata)
        #logging.info(jsondata)
        try:
   
            
            if jsondata.get('data'):
                if jsondata['data'].get('object'):
                    stripe_cust_id = jsondata['data']['object']['customer']

            if stripe_cust_id == "" and jsondata.get('data'):
                stripe_cust_id = jsondata['data']['customer']

            if stripe_cust_id == "" and jsondata.get('customer'):
                stripe_cust_id = jsondata['customer']
            
            if jsondata.get('data'):
                if jsondata['data'].get('object'):
                    invoice_no = jsondata['data']['object']['invoice']

            if invoice_no == "" and jsondata.get('data'):
                invoice_no = jsondata['data']['invoice']

            if invoice_no == "" and jsondata.get('invoice'):
                invoice_no = jsondata['invoice']

                      
           
            payment_status = "paid"

            if jsondata.get('data'):
                if jsondata['data'].get('object'):
                    ramount = jsondata['data']['object']['amount_received']

            if ramount == 0 and jsondata.get('data'):
                ramount = jsondata['data']['amount_received']

            if ramount == 0 and jsondata.get('amount_received'):
                ramount = jsondata['amount_received']

            if ramount == 0 and jsondata.get('amount_total'):
                ramount = jsondata['amount_total']

            #print("ramount")
            #print(ramount)

            amount = round((int(ramount) / 100),2)
            date_updated = datetime.utcnow()

            #print("amount")
            #print(amount)

            existing = Users.find_one({"stripe_cust_id": stripe_cust_id,"new_subscription_level":{"$ne":""}})

            #print(existing)
            #logging.info("before exisiting............\r\n")
            
            if existing:
                try:    
                   
                    logging.info("email:"+existing['email']+"\r\n")
                    logging.info("stripe_cust_id:"+stripe_cust_id+"\r\n") 
                    logging.info("amount:")  
                    logging.info(str(amount))
                    logging.info("\r\n")
                    logging.info("invoice_no:")
                    logging.info(invoice_no)
                    logging.info("\r\n")   
                    logging.info("payment_status:"+payment_status+"\r\n")  
                    logging.info(date_updated)
                    logging.info("\r\n") 

                    Payment.insert_one({
                        "user_id": existing['email'],
                        "stripe_cust_id": stripe_cust_id,
                        "amount": amount,
                        "invoice_no": invoice_no,
                        "payment_status": payment_status,
                        "payment_date": date_updated,
                        "subscription_level": existing['new_subscription_level']
                    })

                    subscription_level = existing['new_subscription_level']
                    #product_module = existing['new_product_module']
                    #price_id = existing['new_price_id']

                    price_id = ""
                    product_id = ""
                    unit_amount = ""
                    product_module = ""
                    type= ""
                    total_wishes=0

                    pipeline = [
                        {"$unwind": "$plan_details"},
                        { "$match" : {'plan_details.subscription_level':subscription_level }},
                        { "$project" : { "_id":1,
                                        "subscription_level" : '$plan_details.subscription_level',
                                        "total_wishes" : '$plan_details.total_wishes',
                                        "price" : '$plan_details.price',
                                        "period" : '$plan_details.period',
                                        "product_id" : '$plan_details.product_id',
                                        "price_id" : '$plan_details.price_id',
                                        "type" : '$plan_details.type',
                                        "plan_name" : '$plan_details.plan_name',
                                        "product_name" : 1,
                                        "product_module" : 1,
                                        }
                        }            
                    ]
                    products = Products.aggregate(pipeline)
                    for product in products:
                        #print(product["subscription_level"])
                        price_id = product["price_id"]
                        product_id = product["product_id"]
                        unit_amount = product["price"]
                        product_module = product["product_module"]
                        type= product["type"]
                        total_wishes= product["total_wishes"]

                    #update current plan details
                    if type!="addon" and product_module=="Any Code":
                        Users.find_one_and_update(
                            {"email": existing['email']},
                            {"$set": {"stripe_cust_id": stripe_cust_id, "status":"active", 
                                    "subscription_date":date_updated,"payment_status": payment_status,
                                    "subscription_level": subscription_level, "product_module": product_module,
                                    "price_id": price_id,"new_subscription_level":"","new_product_module":"","new_price_id":"",
                                    "free_plan": 0
                                    }},
                        )
        
                        


                    #get the details of plan and update contract count

                    contractcount = 0

                    if type == "addon":
                        oamount = unit_amount
                        contractcount = amount/oamount
                        print(contractcount)
                    elif product_module == "Any Code":
                        contractcount = total_wishes

                    logging.info("===================\r\n") 
                    print("===================\r\n") 
                    logging.info("product_module:"+product_module+"===================\r\n")
                    print("product_module:"+product_module+"===================\r\n")
                    logging.info("subscription_level:"+subscription_level+"===================\r\n")
                    print("subscription_level:"+subscription_level+"===================\r\n")
                    #update contract count
                    if product_module == "Any Code":
                        Users.find_one_and_update(
                            {"email": existing['email']},
                            {
                                "$set":{
                                    "total_wishes": contractcount,
                                    "remaining_wish_count": contractcount
                                }
                            }
                        )  


                   
                except Exception as error:
                    print(error)
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail="There was an error in payment update",
                    )
        except Exception as e:
            return {"message":"Payment update failed","error":str(e)}
        return {'message': payload}, 200
