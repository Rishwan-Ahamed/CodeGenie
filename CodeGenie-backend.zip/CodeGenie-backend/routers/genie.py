from fastapi import APIRouter, UploadFile, File, Body
import requests
from docx import Document
from docx2pdf import convert
import os
from fpdf import FPDF

from utils import generate_filename
from database import Users, Products, Prompts
import logging
import traceback
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT


router = APIRouter()


@router.post("/image")
async def upload_image(image: list[UploadFile] = File(...)):
    total_content = await image[0].read()
    total_content = total_content.decode("utf-8")
    return {"content": str(total_content)}


@router.post("/url")
async def process_url(url: str = Body(..., embed=True)):
    UnstructuredURLLoader = download_loader("UnstructuredURLLoader")
    print(url)
    urls = [url]

    loader = UnstructuredURLLoader(
        urls=urls, continue_on_failure=False, headers={"User-Agent": "value"}
    )
    content = loader.load()
    return {"content": content[0].text}


@router.post("/export/{doc_type}/{module}")
async def export_pdf(doc_type: str,  module: str, advice: dict = Body(..., embed=True)):
    file_path = generate_filename(f"1.{doc_type}")

    #get prompt in the proper order
    product = Products.find_one(
        {"product_name": "CodeGenie", "product_module": module}
    )
    prompts = Prompts.find({"product_id": product["_id"]}).sort("order", 1)
    prompts = list(prompts)

    if doc_type == "pdf":
        pdf = FPDF()
        pdf.add_page()
  
        pdf.set_font('Arial', 'B', 25)
        pdf.set_text_color(r=0, g=0, b=0)
        titletext1 = "Code Genie AI"
        # Calculate the width of the text in points
        text_width = pdf.get_string_width(titletext1)
        # Calculate the center position of the page
        center_x = (pdf.w - text_width) / 2
        # Move to the calculated center position
        pdf.set_xy(center_x, pdf.y)
        # Output the text centered on the page
        pdf.cell(text_width, 10, txt=titletext1, align='C')
        pdf.ln()
        
        #titletext2 = "SMART	CONTRACT AUDIT"
        titletext2 = module +" AUDIT"
        # for key, value in advice.items():
        #     if key == "FIX BUGS" :
        #         titletext2 = "ANY CODE AUDIT"

        # Calculate the width of the text in points
        text_width = pdf.get_string_width(titletext2)
        # Calculate the center position of the page
        center_x = (pdf.w - text_width) / 2
        # Move to the calculated center position
        pdf.set_xy(center_x, pdf.y)
        # Output the text centered on the page
        pdf.cell(text_width, 10, txt=titletext2, align='C')
        pdf.ln()


        # Get the dimensions of the page
        page_width = pdf.w
        page_height = pdf.h

        # Open the image file and get its dimensions (you need to replace "image.jpg" with your image file)
        img_width = 225  # Specify the width of your image
        img_height = 225  # Specify the height of your image

        # Calculate the X and Y coordinates to center the image
        x = (page_width - img_width) / 2
        y = (page_height - img_height) / 2

        # Add the image to the PDF at the calculated position
        pdf.image("CodeGenie_Logo.jpg", x, y, img_width, img_height)


        pdf.set_font('Arial', 'B', 15)
        pdf.set_text_color(r=0, g=0, b=256)
        # Text to be hyperlinked
        urltext = "www.code-genie.ai"

        # Calculate the width of the text in points
        text_width = pdf.get_string_width(urltext) 


        # Calculate the center position of the page
        center_x = (pdf.w - text_width) / 2
        # Move to the calculated center position
        pdf.set_xy(center_x, img_height+20)

        # Define the URL you want to link to
        url = "https://www.code-genie.ai"


        # Create a unique link identifier
        link_id = pdf.add_link()

        # Output the text with the hyperlink
        pdf.cell(text_width, 20, txt=urltext, ln=True, link=link_id, align="C")

       
        pdf.ln()


        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pages = 0

        # Initialize a variable to track the total number of pages
        total_pages = 2
        # insert the texts in pdf
        for prompt in prompts:
            for key, value in advice.items():
                if key==prompt["prompt_name"] and value!="":
                    if key:
                        pdf.set_font('Arial', 'B', 12)
                        pdf.set_text_color(r=0, g=0, b=250)
                        pdf.cell(0, 5, txt = key)
                        pdf.ln()
                    if value:
                        pdf.set_font("Arial", size=12)
                        pdf.set_text_color(r=0, g=0, b=0)
                        # Output justified text
                        pdf.multi_cell(0, 5, value)
                        # Line break
                        pdf.ln(10)
                        # Get the current line number
               



        pdf.output(f"./static/{file_path}")

        #document = Document()
        #for key, value in advice.items():
        #    document.add_heading(key)
        #    document.add_paragraph(value)
        #document.save(f"./static/{file_path.replace('.pdf', '.docx')}")
        #try:
        #    convert(
        #        f"./static/{file_path.replace('.pdf', '.docx')}", f"./static/{file_path}"
        #    )
        #except Exception as e:
        #    logging.info("pdf error:")
        #    logging.error(e)
        #    traceback.print_exc() 
        #os.remove(f"./static/{file_path.replace('.pdf', '.docx')}")
    if doc_type == "txt":
        text_content = ""
        text_content += module+ " AUDIT:\n\n"
        for prompt in prompts:
            for key, value in advice.items():
                if key==prompt["prompt_name"] and value!="":
                    if value!="":
                        text_content += f"{key}\n{value}\n\n"
        with open(f"./static/{file_path}", "w") as file:
            file.write(text_content)
    if doc_type == "docx":
        document = Document()
        
        # Add a centered header
        header_paragraph = document.add_paragraph()
        header_run = header_paragraph.add_run(module+" AUDIT")
        header_run.bold = True  # You can customize the formatting as needed
        header_run.font.size = Pt(16)  # Set the font size to 16 points
        header_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        for prompt in prompts:
            for key, value in advice.items():
                if key==prompt["prompt_name"] and value!="":
                    if value!="":
                        document.add_heading(key)
                        document.add_paragraph(value)
        document.save(f"./static/{file_path}")
    return {"path": file_path}

@router.post("/remaining_wish_count")
def remaining_wish_count(email: str):
    remaining_wish_count=0
    try:
        user = Users.find_one({"email": email})
        remaining_wish_count = user["remaining_wish_count"]
    except Exception as e:
        return { "status": "error", "message":"Wish count failed", "error":str(e) }
    return { "status": "success",'message': "updated wish count", "remaining_wish_count": remaining_wish_count }
