import html
from pyexpat import model
#import tokenize
from fastapi import APIRouter, HTTPException, Request, status, File, UploadFile, Form
from bson.objectid import ObjectId
from pymongo import ASCENDING
import openai
import asyncio
import random
import re
#import xml.etree.ElementTree as ET
import datetime
from flask import Flask, jsonify
from starlette.responses import StreamingResponse
from docx import Document
import fitz  # PyMuPDF

from database import BlogSummary_QA, BlogSummary_live, Prompts, Products, BlogSummary
from schemas.promptSchemas import PromptBaseSchema, RunPromptSchema, BlogSummarySchema
from serializers.promptsSerializers import promptsEntity
from serializers.blogsSerializers import blogsEntity
from database import Users
from datetime import datetime
#from computerender import Computerender
import requests
#import json
import urllib.parse
import boto3
import time
import csv
from urllib.parse import quote
#from transformers import AutoTokenizer, AutoModel
#import torch
#import pinecone
#import pinecone
#from datasets import load_dataset
# Import the necessary module or class
#import langchain
#from tqdm.auto import tqdm  # this is our progress bar

router = APIRouter()

ALLOWED_EXTENSIONS = {'pdf', 'docx'}
MAX_FILE_SIZE = 1 * 1024 * 1024  # 1 MB

@router.get("/")
async def get_prompts():
    pipeline = [
        {
            "$lookup": {
                "from": "products",
                "localField": "product_id",
                "foreignField": "_id",
                "as": "populated_product",
            }
        },
        {"$unwind": "$populated_product"},
        {
            "$project": {
                "product_name": "$populated_product.product_name",
                "product_module": "$populated_product.product_module",
                "plan": 1,
                "prompt_name": 1,
                "order": 1,
                "prompt": 1,
            }
        },
    ]
    prompts = list(Prompts.aggregate(pipeline))
    prompts = promptsEntity(prompts=prompts)
    return {"status": "success", "data": prompts}



@router.post("/")
async def add_prompt(prompt: PromptBaseSchema):
    product = Products.find_one(
        {"product_name": prompt.product, "product_module": prompt.module}
    )
    Prompts.insert_one(
        {
            "product_id": ObjectId(product["_id"]),
            "plan": prompt.plan,
            "prompt_name": prompt.prompt_name,
            "order": prompt.order,
            "prompt": prompt.prompt,
        }
    )
    return {"status": "success"}


@router.patch("/{id}")
async def update_prompt(id: str, prompt: PromptBaseSchema):
    product = Products.find_one(
        {"product_name": prompt.product, "product_module": prompt.module}
    )
    Prompts.update_one(
        {"_id": ObjectId(id)},
        {
            "$set": {
                "product_id": ObjectId(product["_id"]),
                "plan": prompt.plan,
                "prompt_name": prompt.prompt_name,
                "order": prompt.order,
                "prompt": prompt.prompt,
            }
        },
    )
    return {"status": "success"}

@router.get("/search")
async def get_search_prompts(product_name: str, product_module: str, search_key: str):
    

    query =  {"product_id": ObjectId(search_key)}

    project = {
        "product_name": product_name,
        "product_module": product_module,
        "plan": 1,
        "prompt_name": 1,
        "order": 1,
        "prompt": 1,
    }
    prompts = list(Prompts.find(query, projection=project))
    #prompts = list(Prompts.aggregate(pipeline))
    prompts = promptsEntity(prompts=prompts)
    return {"status": "success", "data": prompts}

@router.get("/names")
async def get_prompt_from_products(product_name: str, product_module: str):
    product = Products.find_one(
        {"product_name": product_name, "product_module": product_module}
    )
    pipeline = [
        {"$match": {"product_id": product["_id"]}},
        {
            "$lookup": {
                "from": "products",
                "localField": "product_id",
                "foreignField": "_id",
                "as": "populated_product",
            }
        },
        {"$unwind": "$populated_product"},
        {"$sort": {"order": ASCENDING}},
        {
            "$project": {
                "_id": 0,
                "prompt_name": 1,
            }
        },
    ]
    prompts = Prompts.aggregate(pipeline)
    return {"status": "success", "data": list(prompts)}


async def dispatch_openai_requests(
    model: str, prompts: list[str], code: str
) -> list[str]:
    """Dispatches requests to OpenAI API asynchronously.

    Args:
        prompts: List of prompts to be sent to OpenAI ChatCompletion API.
        model: OpenAI model to use.
    Returns:
        List of responses from OpenAI API.
    """
    async_responses = [
        openai.ChatCompletion.acreate(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are CodeGenie that helps people with code.",
                },
                {
                    "role": "user",
                    "content": f"{prompt}\n\n++++++++++++++++++++\n\n{code}\n\n++++++++++++++++++++",
                },
            ],
            temperature=0.5
        )
        for prompt in prompts
    ]
    return await asyncio.gather(*async_responses)

async def dispatch_openai_requests_blog(
    model: str, prompts: list[str], code: str
) -> list[str]:
    """Dispatches requests to OpenAI API asynchronously.

    Args:
        prompts: List of prompts to be sent to OpenAI ChatCompletion API.
        model: OpenAI model to use.
    Returns:
        List of responses from OpenAI API.
    """
    async_responses = [
        openai.ChatCompletion.acreate(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are CodeGenie that helps people with code.",
                },
                {
                    "role": "user",
                    "content": f"{prompt}\n\n++++++++++++++++++++\n\n{code}\n\n++++++++++++++++++++",
                },
            ],
            temperature=0.7,
        )
        for prompt in prompts
    ]
    return await asyncio.gather(*async_responses)


async def dispatch_openai_requests_blog_details(
    model: str, prompts: list[str], code: str
) -> list[str]:
    """Dispatches requests to OpenAI API asynchronously.

    Args:
        prompts: List of prompts to be sent to OpenAI ChatCompletion API.
        model: OpenAI model to use.
    Returns:
        List of responses from OpenAI API.
    """
    async_responses = [
        
        openai.ChatCompletion.acreate(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are CodeGenie that helps people with code.",
                },
                {
                    "role": "user",
                    "content": f"{prompt}\n\n++++++++++++++++++++\n\n{code}\n\n++++++++++++++++++++",
                },
            ],
            temperature=1,
        )
        for prompt in prompts
    ]
    return await asyncio.gather(*async_responses)

# def fake_streamer(n):
#     for i in range(int(n)):
#         yield f"{i}"
#         time.sleep(1)
def get_openai_generator(prompt, code):
    openai_stream = openai.ChatCompletion.create(
        model="gpt-4-0125-preview",
        messages=[
            {
                "role": "system",
                "content": "You are CodeGenie that helps people with code.",
            },
            {
                "role": "user",
                "content": f"{prompt}\n\n++++++++++++++++++++\n\n{code}\n\n++++++++++++++++++++",
            },
        ],
        stream=True,
        temperature=0.5
    )
    for event in openai_stream:
        if "content" in event["choices"][0].delta:
            current_response = event["choices"][0]["delta"]["content"]
            yield current_response


@router.post("/run_stream_test")
async def stream_prompt(request: Request):
    info = await request.json()
    product = Products.find_one(
        {"product_name": info["product_name"], "product_module": info["product_module"]}
    )
    prompts = Prompts.find({"product_id": product["_id"], "prompt_name": info["prompt"]}).sort("order", 1)
    prompts = list(prompts)
    print("prompts run")
    print(prompts)
    prompt_list = []
    prompt_index_list = []
    prompt_index = -1
    for prompt in prompts:
        prompt_index = prompt_index + 1
        # check subscription level
        if 'plan' in prompt:
            if info["free_plan"] == 1 or prompt["plan"] == "" or prompt["plan"] is None or prompt["plan"].find(
                    info["subscription_level"]) != -1:
                prompt_list.append(prompt["prompt"])
                prompt_index_list.append(prompt_index)
            elif info["free_plan"] == 0 and info["subscription_level"] == "Free":
                prompt_list.append(prompt["prompt"])
                prompt_index_list.append(prompt_index)
        else:
            prompt_list.append(prompt["prompt"])
            prompt_index_list.append(prompt_index)
    print("prompt_list")
    print(prompt_list)
    # return StreamingResponse(fake_streamer(10), media_type='application/json')
    if len(prompt_list) > 0:
        try:
            return StreamingResponse(get_openai_generator(prompt_list[0], info["code"]), media_type='text/event-stream')
        except TimeoutError:
            return "No output"
    return "No output"


@router.post("/run_stream")
def stream_prompt(info: RunPromptSchema):
    product = Products.find_one(
        {"product_name": info.product_name, "product_module": info.product_module}
    )
    prompts = Prompts.find({"product_id": product["_id"]}).sort("order", 1)
    prompts = list(prompts)
    print("prompts run")
    print(prompts)
    # info.subscription_level
    # prompt_list = []
    # prompt_index_list = []
    # prompt_index = -1
    # for prompt in prompts:
    #     prompt_index = prompt_index + 1
    #     # check subscription level
    #     if 'plan' in prompt:
    #         if info.free_plan == 1 or prompt["plan"] == "" or prompt["plan"] is None or prompt["plan"].find(
    #                 info.subscription_level) != -1:
    #             prompt_list.append(prompt["prompt"])
    #             prompt_index_list.append(prompt_index)
    #         elif info.free_plan == 0 and info.subscription_level == "Free":
    #             prompt_list.append(prompt["prompt"])
    #             prompt_index_list.append(prompt_index)
    #     else:
    #         prompt_list.append(prompt["prompt"])
    #         prompt_index_list.append(prompt_index)
    # predictions = asyncio.run(
    #     dispatch_openai_requests(
    #         model="gpt-4-1106-preview", prompts=prompt_list, code=info.code
    #     )
    # )
    reply = {
        'SUMMARY': 'This code is written in Python and uses the requests library to make a request to a specific URL. The purpose of this code is to stream data from the specified URL. \n\nThe code starts by importing the requests library. It then defines a variable called "url" with the value of "http://localhost:8000/stream/". This is the URL from which the data will be streamed.\n\nNext, the code enters a "with" statement, which ensures that the request is properly closed after it is done. Within the "with" statement, the code uses the "requests.get()" function to make a GET request to the specified URL. The "stream" parameter is set to True, indicating that the response should be streamed.\n\nThe code then enters a "for" loop, where it iterates over the content of the response in chunks. The "iter_content()" function is used to iterate over the content of the response in chunks. The first parameter of this function is set to "None", indicating that the default chunk size should be used. \n\nWithin the loop, the code prints each chunk of data that it receives. This allows the data to be processed or displayed as it is being streamed.\n\nOverall, this code is a simple example of how to stream data from a URL using the requests library in Python. It provides a high-level overview of the code\'s purpose, structure, and main functions.',
        'ANALYSIS': "This code snippet makes use of the requests library to send a GET request to a specified URL and stream the response data. Let's analyze its complexity, efficiency, and potential bottlenecks.\n\n1. Complexity:\n   - Time Complexity: The time complexity of this code mainly depends on the size of the response data. Since it streams the data chunk by chunk, the time complexity can be considered as O(n), where n is the size of the response data.\n   - Space Complexity: The space complexity is relatively low as it only requires memory to store each chunk of data. Therefore, the space complexity can be considered as O(1).\n\n2. Efficiency:\n   - The code uses the `requests.get()` function to send a GET request to the specified URL. The `stream=True` parameter enables streaming of the response data instead of loading it entirely into memory. This is efficient when dealing with large response data, as it allows for processing the data in smaller chunks rather than loading it all at once.\n\n3. Potential Bottlenecks:\n   - Network Latency: The code relies on making a network request to the specified URL. The efficiency of the code can be affected by network latency or any issues with the network connection.\n   - Server Performance: The efficiency of the code also depends on the performance of the server hosting the requested resource. If the server is slow or overloaded, it may impact the overall performance of the code.\n   - Resource Consumption: Streaming large amounts of data can consume system resources, especially if the data processing or printing operations within the loop are computationally expensive. It's important to ensure that the code within the loop is optimized to avoid potential bottlenecks.\n\nOverall, this code snippet efficiently streams the response data from the specified URL, making it suitable for handling large amounts of data. However, the efficiency of the code can still be impacted by external factors such as network latency and server performance.",
        'FIX BUGS': 'This output identifies any bugs or errors in the code and tries to fix any bug or error found. It helps developers fix issues before they become problems in production.\n\n++++++++++++++++++++\n\nimport requests\n\nurl = "http://localhost:8000/stream/"\n\nwith requests.get(url, stream=True) as r:\n    for chunk in r.iter_content(None):\n        print(chunk)\n\n++++++++++++++++++++\n\nImprovements:\n- Add error handling to handle any exceptions that may occur during the request.\n- Use a try-except block to catch any potential errors during the request.\n- Add headers to the request to provide more information to the server.\n- Consider adding a timeout parameter to the request to avoid long waits for a response.',
        'TEST CASES': 'This output provides test cases that the developer, QA or QE Engineer can use to test the code.\n\nTest Coverage:\n\n1. Test the code with a valid URL:\n   - Set the `url` variable to a valid URL.\n   - Run the code and verify that the request is successfully made to the specified URL.\n   - Verify that the response is received and the chunks of content are printed.\n\n2. Test the code with an invalid URL:\n   - Set the `url` variable to an invalid URL.\n   - Run the code and verify that an error or exception is raised due to the invalid URL.\n\n3. Test the code with a non-streaming request:\n   - Modify the code to set `stream=False` in the `requests.get()` function.\n   - Run the code and verify that the request is successfully made to the specified URL.\n   - Verify that the response is received and the content is printed as a single chunk.\n\n4. Test the code with a larger chunk size:\n   - Modify the code to set a larger value for the second argument of `r.iter_content()`.\n   - Run the code and verify that the chunks of content are printed with the specified larger size.\n\n5. Test the code with a smaller chunk size:\n   - Modify the code to set a smaller value for the second argument of `r.iter_content()`.\n   - Run the code and verify that the chunks of content are printed with the specified smaller size.\n\n6. Test the code with a different content type:\n   - Modify the code to set a different URL that returns a different content type (e.g., image, JSON, etc.).\n   - Run the code and verify that the request is successfully made to the specified URL.\n   - Verify that the response is received and the chunks of content are printed.\n\nNote: These test cases assume that the code is not a smart contract.',
        'NEW FEATURES': 'This output is to suggest new features that can be considered or added to your backlog to enhance the value of the application.\n\n1. User Authentication: Implement a user authentication system to ensure that only authorized users can access the stream. This will enhance security and privacy.\n\n2. Error Handling: Add error handling to the code to handle cases where the server is not available or there are network issues. This will improve the reliability and user experience of the application.\n\n3. Real-time Updates: Instead of just printing the chunks as they are received, consider implementing real-time updates that display the chunks in a more user-friendly format, such as a live stream or a progress bar.\n\n4. Pause/Resume Functionality: Allow users to pause and resume the stream, so they can control when they want to receive the chunks. This will provide more flexibility and convenience for the users.\n\n5. Data Filtering: Add the ability to filter the received chunks based on specific criteria, such as keywords or patterns. This will allow users to focus on the data that is most relevant to them and improve the efficiency of the application.',
        'REFACTOR': 'This output provides suggestions for refactoring the code to make it cleaner, more efficient, and easier to maintain. It helps developers improve the quality of their code.\n\nRefactoring suggestions for the provided code:\n\n1. Import requests module at the beginning of the code, before any other statements.\n2. Use meaningful variable names to improve code readability.\n3. Add error handling to handle potential exceptions when making the HTTP request.\n4. Close the response object after processing the request to release system resources.\n5. Use a try-except-finally block to ensure proper cleanup even in case of exceptions.\n6. Use a constant or configuration file to store the URL instead of hardcoding it in the code.\n\nHere\'s the refactored code:\n\n```python\nimport requests\n\nURL = "http://localhost:8000/stream/"\n\ntry:\n    with requests.get(URL, stream=True) as response:\n        for chunk in response.iter_content(None):\n            print(chunk)\nexcept requests.RequestException as e:\n    print("An error occurred:", e)\nfinally:\n    response.close()\n```\n\nPlease note that the refactored code assumes that you want to print each chunk of data received from the URL. Adjust the code according to your specific requirements.',
        'STRUCTURE': 'This output shows an overview of the data structure and elements present in the provided code.\n\nData Structure:\n- Global variables: None\n- Local variables: url, r, chunk\n- Functions & methods: import, requests.get(), r.iter_content(), print()\n- Constants: None\n- Control structures: with statement, for loop\n- Comments & notes: None\n- Operations: assignment (=), function call (requests.get()), method call (r.iter_content()), print statement\n\nPlease note that the code you provided is incomplete and contains syntax errors.',
        'MICROSERVICES': 'This code snippet is written in Python and it is making a GET request to a specified URL. It is streaming the response and printing each chunk of data received.\n\nTo convert this code into a microservice, you can follow these steps:\n\n1. Create a new file and save it with a ".py" extension, for example, "microservice.py".\n2. Copy and paste the provided code into the "microservice.py" file.\n\nNext, you can define the functionality of your microservice based on your requirements. Here\'s an example of how you can modify the code to create a microservice:\n\n```python\nimport requests\nfrom flask import Flask\n\napp = Flask(__name__)\n\n@app.route("/")\ndef stream_data():\n    url = "http://localhost:8000/stream/"\n    with requests.get(url, stream=True) as r:\n        for chunk in r.iter_content(None, decode_unicode=True):\n            # Do something with each chunk of data\n            print(chunk)\n    return "Data streaming completed"\n\nif __name__ == "__main__":\n    app.run()\n```\n\nIn this example, we are using the Flask framework to create a microservice. We define a route ("/") that will handle the incoming requests. Inside the route function, we have added the code from the original snippet.\n\nYou can customize the code inside the `stream_data()` function to process the received data according to your requirements. Instead of printing each chunk, you can perform any necessary operations on the data.\n\nTo run the microservice, make sure you have Flask installed (you can install it using `pip install flask`). Then, you can execute the "microservice.py" file, and the microservice will start running on your local machine.\n\nKeep in mind that this is just a basic example, and you might need to modify the code further based on your specific needs.',
        'SECURITY': 'This output identifies any potential security vulnerabilities in the code. It helps developers ensure that their code is secure and resistant to attacks.\n\nPotential security vulnerability:\n\n1. Insecure use of the requests library: The code is using the requests library to make HTTP requests. However, it is not validating the SSL certificate of the server it is connecting to. This can lead to potential man-in-the-middle attacks and data leakage. It is recommended to enable SSL certificate verification by setting the `verify` parameter to `True` in the `requests.get()` function.\n\nAdditionally, it seems like there is a syntax error in the code. The `print(chunk)` statement is not properly indented. It should be indented within the for loop.\n\nHere is the modified code with the suggested changes:\n\n++++++++++++++++++++\n\nimport requests\n\nurl = "http://localhost:8000/stream/"\n\nwith requests.get(url, stream=True, verify=True) as r:\n    for chunk in r.iter_content(None):\n        print(chunk)\n\n++++++++++++++++++++',
        'STANDARDS': 'This code snippet appears to be written in Python. Based on the code provided, there are a few issues with compliance with coding standards and style guidelines:\n\n1. Indentation: The code has inconsistent indentation. It is recommended to use consistent indentation (usually four spaces) to improve code readability.\n\n2. Missing closing parenthesis: The line `for chunk in r.iter_content(None, print(chunk)` is missing a closing parenthesis after `print(chunk)`.\n\n3. Comment: It is good practice to include comments in the code to explain its purpose or any complex logic. However, there are no comments present in the provided code.\n\nHere\'s the updated code with the mentioned issues addressed:\n\n```python\nimport requests\n\nurl = "http://localhost:8000/stream/"\n\nwith requests.get(url, stream=True) as r:\n    for chunk in r.iter_content(None):\n        print(chunk)\n```\n\nPlease note that without further context or specific coding standards, it is difficult to identify all potential issues. It is always recommended to follow the coding standards and style guidelines specified by the project or organization you are working with.',
        'SMILE': "Sure! Here's a random professional joke for you:\n\nWhy don't scientists trust atoms?\n\nBecause they make up everything!"
    }
    # reply = {
    #     'SUMMARY': fake_video_streamer(3),
    #     'ANALYSIS': fake_video_streamer(4),
    #     'FIX BUGS': fake_video_streamer(5),
    #     'TEST CASES': fake_video_streamer(3),
    #     'NEW FEATURES': fake_video_streamer(6),
    #     'REFACTOR': fake_video_streamer(4),
    #     'STRUCTURE': fake_video_streamer(3),
    #     'MICROSERVICES': fake_video_streamer(4),
    #     'SECURITY': fake_video_streamer(3),
    #     'STANDARDS': fake_video_streamer(5),
    #     'SMILE': fake_video_streamer(8),
    # }
    return {"status": "success", "msg": reply}



@router.post("/run")
def run_prompt(info: RunPromptSchema):
    product = Products.find_one(
        {"product_name": info.product_name, "product_module": info.product_module}
    )
    prompts = Prompts.find({"product_id": product["_id"]}).sort("order", 1)
    prompts = list(prompts)
    print("prompts")
    print(prompts)
    #info.subscription_level
    prompt_list = []
    prompt_index_list = []
    prompt_index = -1
    for prompt in prompts:
        prompt_index = prompt_index + 1
        #check subscription level
        if 'plan' in prompt:
            if info.free_plan == 1 or prompt["plan"] == "" or prompt["plan"] is None or prompt["plan"].find(info.subscription_level)!=-1:
                prompt_list.append(prompt["prompt"])
                prompt_index_list.append(prompt_index)
            elif info.free_plan == 0 and info.subscription_level == "Free": 
                prompt_list.append(prompt["prompt"])
                prompt_index_list.append(prompt_index)
        else:
            prompt_list.append(prompt["prompt"])
            prompt_index_list.append(prompt_index)
    predictions = asyncio.run(
        dispatch_openai_requests(
            model="gpt-4-0125-preview", prompts=prompt_list, code=info.code
        )
    )

    print("predictions::::")
    print(predictions)
    reply = {}
    #complexity=""
    for i, prediction in enumerate(predictions):
        reply[prompts[prompt_index_list[i]]["prompt_name"]] = prediction.choices[0].message.content
        
    if info.free_plan==1:
        Users.find_one_and_update(
            {"email": info.email},
            {"$set": {"free_plan": 0}}
        )
    print(info.free_plan)
    print("info.product_module")
    print(info.product_module)

    existing = Users.find_one({"email": info.email})

    #if remaining count <=0 , then don't increment, just update
    remainingcount = existing['remaining_wish_count']
    if(info.product_module != "SMART CONTRACTS"):
        if remainingcount>0:
            Users.find_one_and_update(
                    {"email": info.email},
                    {"$inc": {"used_wish_count": 1, "remaining_wish_count": -1}},
            )
    return {"status": "success", "msg": reply}


@router.get("/reduceWishCount")
def set_wish_count(userid: str):
    existing = Users.find_one({"email": userid})

    #if remaining count <=0 , then don't increment, just update
    remainingcount = existing['remaining_wish_count']

    if remainingcount>0:
        Users.find_one_and_update(
                {"email": userid},
                {"$inc": {"used_wish_count": 1, "remaining_wish_count": -1}},
        )

    return {"status": "success", "msg": "Wish count updated"}


@router.post("/runautoblog")
def run_prompt():
    #cr = Computerender("sk_aBIr16LFau4ZgKjER1b-S")

    print("********************************")

    #step 1
    #read pending categories from prompt collection
    #cats = Prompts.find({"processed":False,"$expr": { "$lt": ["$completed_count", "$order"]}}).limit(1).skip(0).sort("_id",1)
    cats = Prompts.find({"processed":False,"$expr": { "$lt": ["$completed_count", "$order"]}, "prompt":"Artificial Intelligence"}).limit(1).skip(0).sort("_id",1)


    # Iterate over the cursor to access the result
    cat = ""
    promptid = ""
    productid = ""
    product_module = ""
    blog_count = 0
    blog_count_to_be_created = 0
    total_count = 0
    blog_list = []
    for document in cats:
        cat = document["prompt"]
        promptid = str(document["_id"])
        productid = str(document["product_id"])
        total_count =  document["order"]
        blog_count = document["completed_count"]
        blog_count_to_be_created = document["order"] - document["completed_count"]

    #get product module name from product collection
    if cat.strip()!="":
        product = Products.find({"_id":ObjectId(productid)})
        for document in product:
            product_module = document["product_module"]

    #step 2
    # if cat found, then read prompt for prouct description using the product id
    prompt_description = ""
    if cat.strip()!="":
        rec = Prompts.find({"product_id":ObjectId(productid),"prompt_name":"PRODUCT DESCRIPTION"})
        if rec:
            for document in rec:
                prompt_description = document["prompt"]
            
    #step 3
    #if prompt found from the previous step, then get the actual prompt to be executed
    prompt = ""
    if prompt_description.strip()!="":
        rec = Prompts.find({"product_id":ObjectId(productid),"prompt_name":"CREATE SUMMARY"})
        if rec:
            for document in rec:
                prompt = document["prompt"]

    #if actual prompt found, then reaplce {PRODUCT DESCRIPTION} with actual value we got it from previous step 2
    if prompt.strip()!="":
        prompt = prompt.replace("{PRODUCT DESCRIPTION}", prompt_description)
        prompt = prompt.replace("{COUNT}",str(blog_count_to_be_created))
        prompt = prompt.replace("{BLOG-CATEGORY}",cat)
       
        #return {"cat": cat, "promptid":promptid, "prompt":prompt}
        print(prompt)
    
        #if everything fine, then execute the propt and generate blog summary and title
        temperature = 0.7  # Set the desired temperature
        #info.subscription_level
        prompt_list = []
        prompt_list.append(prompt)
        predictions = asyncio.run(
            dispatch_openai_requests_blog(
                model="gpt-4-0125-preview", prompts=prompt_list, code=""
            )
        )
        reply = {}

        print("\n\n")
        print("Pridiction Result")
        print("********************************")
        print(predictions)
        

        print("\n\n")
        print("********************************")

        #complexity=""
        for i, prediction in enumerate(predictions):
            print("\n\n")
            #print(prediction.choices[0].message.content)
            #split result from open api and insert into db
            # print(prediction.choices[0].message.content)
           

            #message = prediction.choices[0].message.content.split("Summary:")
            message = prediction.choices[0].message.content
            
            # Split the text using "Title:" as the separator
            sections = re.split(r'Title:', message)

            print("\nSectionh.....\n\n")
            print(sections)

            if(len(sections)<=0):
                print("\n\n\n")
                print("issue with result.....")

            # Extract titles and summaries
            title_summary_pairs = []
            for section in sections[1:]:  # Start from index 1 to skip the empty string before the first title
                title_match = re.split(r'Summary:', section)
                

                if title_match:
                    title = title_match[0].replace("Title:","").strip()
                    summary = title_match[1].replace("Summary:","").strip()
                    print("Title:"+title)
                    print("Summary:"+summary)
                    print("\n\n")
                    title_summary_pairs.append([title, summary])

            # Print the result
            for pair in title_summary_pairs:
                title = pair[0]
                blog_summary = pair[1]
               
                ##filename = "static/"+str(random_int)+"_blog_image.jpg"
                filename = "/images/blogs12.png"
                image_string = title
                 #insert detail in to blog_summary collection
                BlogSummary.insert_one({
                    "blog_title": title,
                    "blog_title_draft": title,
                    "blog_image_string": image_string,
                    "blog_image_string_draft": image_string,
                    "blog_summary": blog_summary,
                    "blog_summary_draft": blog_summary,
                    "blog_image_path": filename,
                    "blog_image_path_draft": filename,
                    "cat":product_module,
                    "flag":0,
                    "product_id":ObjectId(productid),
                    "prompt_id":ObjectId(promptid)
                })

                #update blog creation count
                blog_count = blog_count + 1
                processed = False
                if blog_count >= total_count:
                    processed = True
                Prompts.find_one_and_update({"_id":ObjectId(promptid)},{"$set":{"completed_count":blog_count,"processed":processed}})

    return {"status": "success", "msg": reply}


@router.post("/generateautoblogcontent")
def genertae_auto_content():
    #get the generated blog summary which flag as 0 , represents only title and summary available
    #content not yet generated
    recs = BlogSummary.find({"flag":0}).limit(10).skip(0).sort("_id",1)

    productid = ""
    prompt = ""
    productdesc = ""
    title = ""
    summary = ""
    blogdet = ""
    blogid=""
    for document in recs:
        productid = document["product_id"]
        blogid = str(document["_id"])
        title = document["blog_title"]
        summary = document["blog_summary"]
        print("***********")
        print(document["_id"])
        print(title)
        print(summary)
        print("\n\n")
        #get the create blog prompt for that product id
        promptrec = Prompts.find({"prompt_name":"CREATE BLOGS","product_id":ObjectId(productid)})
        for document1 in promptrec:
            prompt = document1["prompt"]
        
        #get the product description 
        promptrec = Prompts.find({"prompt_name":"PRODUCT DESCRIPTION","product_id":ObjectId(productid)})
        for document2 in promptrec:
            productdesc = document2["prompt"]


        #run the prompt
        if prompt.strip()!="":
            #replace PRODUCT DESCRIPTION
            prompt = prompt.replace("{PRODUCT DESCRIPTION}", productdesc)
            prompt = prompt.replace("+title+",title)
            prompt = prompt.replace("+summary+",summary)

            
            print("\n\n")
            print("prompt Result")
            print("********************************")
            print(prompt)

            
            #if everything fine, then execute the propt and generate blog summary and title
            temperature = 0.7  # Set the desired temperature
            #info.subscription_level
            prompt_list = []
            prompt_list.append(prompt)
            predictions = asyncio.run(
                # dispatch_openai_requests_blog(
                #     model="gpt-4-1106-preview", prompts=prompt_list, code=""
                # )
                 dispatch_openai_requests_blog(
                    model="gpt-4-0125-preview", prompts=prompt_list, code=""
                )
            )
            reply = {}

            print("\n\n")
            print("Pridiction Result")
            print("********************************")
            print(predictions)
            

            print("\n\n")
            print("********************************")

            #create url
            url = title.replace(" ","_")
            url = title.replace(":","_")
            # Replace \n\r  using a regular expression
            url = re.sub(r'\n', '', url) 
            url = re.sub(r'\b', '_', url)
            url = url.replace("_ ","_")
            url = url.replace("__","_")
            url = url.replace(" ","")   
            url = re.sub(r'\b', '', url)  

           
            for i, prediction in enumerate(predictions):
                print("\n\n")
                #print(prediction.choices[0].message.content)
                #split result from open api and insert into db

                message = prediction.choices[0].message.content.split("Summary: ")
                current_datetime = datetime.now()
                if len(message) <= 1:
                    tmpmessage = prediction.choices[0].message.content
                    message = tmpmessage.split("Title: ")
                    print("message========")
                    print(message[1])

               
                if len(message) > 1:
                    blogdet = message[1]
                    print("Blogdet::::")
                    print(blogdet)
    

                    #clean up blog data and do some formatting
                    pattern = r'^(Paragraph [0-9]*:)(.*)$'
                    replacement_text = r"<br><h3>\2</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^(Blogging [0-9]*:)(.*)$'
                    replacement_text = r"<br><h3>\2</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^(Paragraph [0-9]* Heading:)(.*)$'
                    replacement_text = r"<br><h3>\2</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^(.*):$'
                    replacement_text = r"\1"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^In conclusion,'
                    replacement_text = r"<br><h3>Conclusion</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE) 

                    pattern = r'^Conclusion$'
                    replacement_text = r"<br><h3>Conclusion</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^Introduction$'
                    replacement_text = r"<br><h3>Introduction</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^Real-Time Bug and Issue Fixes'
                    replacement_text = r"<br><h3>Real-Time Bug and Issue Fixes</h3></br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^Time and Cost Efficiency$'
                    replacement_text = r"<br><h3>Time and Cost Efficiency</h3><br>"
                    # Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    pattern = r'^Paragraph 1 Heading$'
                    replacement_text = r"</br>"
                    #Replace the matched lines with the replacement text
                    blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                    print("\n\n")
                    print("Blog details")
                    print("-------------------\n")
                    print(blogdet)

                    #update blog summary details
                    if blogdet.strip()!="":
                        BlogSummary.find_one_and_update({"_id":ObjectId(blogid)},
                                            {
                                                "$set":{
                                                        "blog_det":blogdet,
                                                        "url":url,
                                                        "image_updated":"No",
                                                        "mode":"Live",
                                                        "publish_date":current_datetime,
                                                        "created_date":current_datetime,
                                                        "updated_date":current_datetime,
                                                        "seo_score":0,
                                                        "total_views":0,
                                                        "rattings":0,
                                                        "flag":1
                                                }
                                            }
                                        )



 
@router.post("/generatecontent")
def generate_content(cat: str, title: str, prompt: str):
    prompts = """"""+prompt+""""""

    temperature = 0.7  # Set the desired temperature

    #info.subscription_level
    prompt_list = []
    prompt_list.append(prompts)
    predictions = asyncio.run(
        dispatch_openai_requests_blog(
            model="gpt-4-0125-preview", prompts=prompt_list, code=""
        )
    )
    reply = {}

   

    #complexity=""
    for i, prediction in enumerate(predictions):
        print("\n\n")
        #print(prediction.choices[0].message.content)
        #split result from open api and insert into db
        message = prediction.choices[0].message.content.split("Summary:")
        summary = message[1]
        message = message[0].split("DALL-E:")
        imageString = message[1]
        message = message[0].split("Title:")
        #title = message[1]
        reply[i] = prediction.choices[0].message.content

    
    content = reply[0].split("Title: ")
    index = 0
    for key in content:
        if index == 0: 
            index = index + 1
            continue
        #title = key.split("DALL-E: ")[0]
        remcontent =  key.split("DALL-E: ")[1]
        image_string = remcontent.split("Summary: ")[0]
        blog_summary = remcontent.split("Summary: ")[1]
        print("summary::" + summary)
        print("image_string::" + image_string)
        print("blog_summary::" + blog_summary)

        # Generate a random integer between a specified range (inclusive)
        random_int = random.randint(1, 10000)  # Random integer between 1 and 10       

        index = index + 1
        random_int = random_int + index

        # optionally write to file
        ##filename = "static/"+str(random_int)+"_blog_image.jpg"
        filename = "/images/blogs12.png"
        #with open(filename, "wb") as f:
        #    f.write(img_bytes)

        #generate content  details ########################


        url = title.replace(" ","_")
        url = title.replace(":","_")
        # Replace \n\r with "cat" using a regular expression
        url = re.sub(r'\n', '', url) 
        url = re.sub(r'\b', '_', url)
        url = url.replace("_ ","_")
        url = url.replace("__","_")
        url = url.replace(" ","")   
        url = re.sub(r'\b', '', url)         
        print("url:::")
        print(url)
        summary = blog_summary
        summary = re.sub(r'\n', '', summary) 
        title = re.sub(r'\n', '', title) 

        prompts = """+++ BEGIN PROMPT
 
Code Genie is a versatile AI tool that can audit a wide range of smart contracts from a variety of blockchain networks. Code Genie use an LLM model to analyze smart contract code. Code Genie can audit and fix virtually any smart contract within seconds, with 1-click. Smart Contract audits includes Functionality, Security, Gas Usage, Visibility, Variables, Event Logs, Upgradability, Ownership, Balance, Fallback, Self Destruct, Exploit Scenarios, and Code Fix. Code Genie's smart contract audit is extremely accurate. Code Genie uses Large Language Model AI that does a full analysis of smart contract code. The AI will find things that the human eyes will miss. Code Genie will even attempt to fix the bugs and issues found in your contract for your developers in real time. Code Genie is Extremely Fast & Easy to Use. Leveraging new AI technology, Code Genie is able to do a full smart contract audit in a few seconds, with just 1-click. You do not need to know anything about coding to self-audit your contracts. You can Try it for Free. Code Genie is Extremely Affordably. Code Genie is a fraction of the cost when compared to industry average or other competitors. Code Genie's Do It Yourself approach can save you $5,000 to $15,000+, which is the industry average to audit smart contracts. Code Genie pricing is based on the complexity of the contract where pricing starts at $99 per contract.
 
write a full blog article based on the below title and brief summary about Code Genie. Include high quality and longtail keywords for better seo ranking with google search engine.  """+title+""" """+summary+"""
 
The output should follow the below.  The title, Paragraph 1, Paragraph 2, Paragraph 3 in the prompt below are just placeholders. Feel free to replace them with your own specific title, summary, and dall-e prompts.
 
Title: Blogging 101: Getting Started with Your Own Blog
 
Paragraph 1 Heading
Starting a blog is a good thing.  Continue with the paragraph
 
Paragraph 2 Heading
Starting a blog is a good thing.  Continue with the paragraph
 
Paragraph 3 Heading
Starting a blog is a good thing.  Continue with the paragraph
 
+++ END PROMPT"""

        temperature = 0.7  # Set the desired temperature
        #info.subscription_level
        prompt_list = []
        prompt_list.append(prompts)
        predictions = asyncio.run(
            dispatch_openai_requests_blog_details(
                model="gpt-4-0125-preview", prompts=prompt_list, code=""
            )
        )
        reply = {}

        blogdet = ""

        #complexity=""
        blogid = ""
        for i, prediction in enumerate(predictions):
            print("\n\n")
            #print(prediction.choices[0].message.content)
            #split result from open api and insert into db

            message = prediction.choices[0].message.content.split("Summary: ")
            if len(message) > 1:
                blogdet = message[1]
                print("Blogdet::::")
                print(blogdet)
  

                #clean up blog data and do some formatting
                pattern = r'^(Paragraph [0-9]*:)(.*)$'
                replacement_text = r"</br><h3>\2</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^(Blogging [0-9]*:)(.*)$'
                replacement_text = r"</br><h3>\2</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^(Paragraph [0-9]* Heading:)(.*)$'
                replacement_text = r"</br><h3>\2</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^(.*):$'
                replacement_text = r"</br><h3>\1</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^In conclusion,'
                replacement_text = r"</br><h3>Conclusion</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE) 

                pattern = r'^Conclusion$'
                replacement_text = r"</br><h3>Conclusion</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Introduction$'
                replacement_text = r"</br><h3>Introduction</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Real-Time Bug and Issue Fixes'
                replacement_text = r"</br><h3>Real-Time Bug and Issue Fixes</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Time and Cost Efficiency$'
                replacement_text = r"<br><h3>Time and Cost Efficiency<h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Paragraph 1 Heading$'
                replacement_text = r"<br>"
                #Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)
    
        content = {
            "blog_title_draft": title,
            "blog_image_string": image_string,
            "blog_summary_draft": blog_summary,
            "blog_image_path_draft": filename,
            "cat":cat,
            "blog_det_draft":blogdet,
            "url_draft":url,            
            "image_updated":"No",
            "mode":"draft"
        }

        blogid = BlogSummary.insert_one({
            "blog_title_draft": title,
            "blog_image_string": image_string,
            "blog_summary_draft": blog_summary,
            "blog_image_path_draft": filename,
            "cat":cat,
            "blog_det_draft":blogdet,
            "url_draft":url,            
            "image_updated":"No",
            "mode":"draft"
        })

        print("************")
        print(blogid.inserted_id)
   
        return {"status": "success", "msg": content, "blogid": str(blogid.inserted_id)}
    
   
@router.post("/savecontentasdraft")
def update_blog(payload: BlogSummarySchema):
    

    id = payload.id
    blog_title = payload.blog_title
    blog_summary = payload.blog_summary
    blog_det = payload.blog_det
    url = payload.url
    blog_image_path = payload.blog_image

    reply = {}

    blogs = BlogSummary.find_one_and_update(
                    {"_id":ObjectId(id)},
                    {"$set":{"blog_title_draft":blog_title, "blog_summary_draft": blog_summary, 
                             "blog_det_draft": blog_det, "url_draft": url, "blog_image_path_draft": blog_image_path}}
                )
    
    return {"status": "success", "msg": "Record updated successuflly."}


@router.post("/publishcontent")
def update_blog(payload: BlogSummarySchema):
    

    id = payload.id
    blog_title = payload.blog_title
    blog_summary = payload.blog_summary
    blog_det = payload.blog_det
    url = payload.url
    blog_image_path = payload.blog_image
    current_datetime = datetime.now()
   

    reply = {}

    blogs = BlogSummary.find_one_and_update(
                    {"_id":ObjectId(id)},
                    {"$set":{"blog_title":blog_title, "blog_summary": blog_summary, 
                             "blog_det": blog_det, "url": url, "blog_image_path": blog_image_path,"mode":"live","publish_date":current_datetime}}
                )
    
    return {"status": "success", "msg": "Record updated successuflly."}



@router.post("/runautoblogdetail")
def run_prompt(cat: str, limit: int):
    cr = Computerender("sk_aBIr16LFau4ZgKjER1b-S")
    blogsummaries = BlogSummary.find({"cat": cat,"blog_det":{"$eq":None}}).limit(limit)
    blogsummaries = list(blogsummaries)
    index = 0

    for blogsummary in blogsummaries:
        index = index + 1
        print("""Index::: """+str(index))
        title = blogsummary["blog_title"]
        url = title.replace(" ","_")
        url = title.replace(":","_")
        # Replace \n\r with "cat" using a regular expression
        url = re.sub(r'\n', '', url) 
        url = re.sub(r'\b', '_', url)
        url = url.replace("_ ","_")
        url = url.replace("__","_")
        url = url.replace(" ","")   
        url = re.sub(r'\b', '', url)         
        print("url:::")
        print(url)
        summary = blogsummary["blog_summary"]
        summary = re.sub(r'\n', '', summary) 
        title = re.sub(r'\n', '', title) 
        prompts = """+++ BEGIN PROMPT
 
Code Genie is a versatile AI tool that can audit a wide range of smart contracts from a variety of blockchain networks. Code Genie use an LLM model to analyze smart contract code. Code Genie can audit and fix virtually any smart contract within seconds, with 1-click. Smart Contract audits includes Functionality, Security, Gas Usage, Visibility, Variables, Event Logs, Upgradability, Ownership, Balance, Fallback, Self Destruct, Exploit Scenarios, and Code Fix. Code Genie's smart contract audit is extremely accurate. Code Genie uses Large Language Model AI that does a full analysis of smart contract code. The AI will find things that the human eyes will miss. Code Genie will even attempt to fix the bugs and issues found in your contract for your developers in real time. Code Genie is Extremely Fast & Easy to Use. Leveraging new AI technology, Code Genie is able to do a full smart contract audit in a few seconds, with just 1-click. You do not need to know anything about coding to self-audit your contracts. You can Try it for Free. Code Genie is Extremely Affordably. Code Genie is a fraction of the cost when compared to industry average or other competitors. Code Genie's Do It Yourself approach can save you $5,000 to $15,000+, which is the industry average to audit smart contracts. Code Genie pricing is based on the complexity of the contract where pricing starts at $99 per contract.
 
write a full blog article based on the below title and brief summary about Code Genie. Include high quality and longtail keywords for better seo ranking with google search engine.  """+title+""" """+summary+"""
 
The output should follow the below.  The title, Paragraph 1, Paragraph 2, Paragraph 3 in the prompt below are just placeholders. Feel free to replace them with your own specific title, summary, and dall-e prompts.
 
Title: Blogging 101: Getting Started with Your Own Blog
 
Paragraph 1 Heading
Starting a blog is a good thing.  Continue with the paragraph
 
Paragraph 2 Heading
Starting a blog is a good thing.  Continue with the paragraph
 
Paragraph 3 Heading
Starting a blog is a good thing.  Continue with the paragraph
 
+++ END PROMPT"""
        print("pormpts:::::\n\n")
        print(prompts)

        temperature = 0.7  # Set the desired temperature
        #info.subscription_level
        prompt_list = []
        prompt_list.append(prompts)
        predictions = asyncio.run(
            dispatch_openai_requests_blog_details(
                model="gpt-4-0125-preview", prompts=prompt_list, code=""
            )
        ) 
        reply = {}

        #complexity=""
        for i, prediction in enumerate(predictions):
            print("\n\n")
            #print(prediction.choices[0].message.content)
            #split result from open api and insert into db
            message = prediction.choices[0].message.content.split("Summary: ")
            if len(message) > 1:
                blogdet = message[1]
                print("Blogdet::::")
                print(blogdet)
                converted_id = ObjectId(blogsummary["_id"])
                print("blogid:::")
                print(converted_id)

                #clean up blog data and do some formatting
                pattern = r'^(Paragraph [0-9]*:)(.*)$'
                replacement_text = r"</br><h3>\2</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^(Blogging [0-9]*:)(.*)$'
                replacement_text = r"</br><h3>\2</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^(Paragraph [0-9]* Heading:)(.*)$'
                replacement_text = r"</br><h3>\2</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^(.*):$'
                replacement_text = r"</br><h3>\1</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^In conclusion,'
                replacement_text = r"</br><h3>Conclusion</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE) 

                pattern = r'^Conclusion$'
                replacement_text = r"</br><h3>Conclusion</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Introduction$'
                replacement_text = r"</br><h3>Introduction</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Real-Time Bug and Issue Fixes'
                replacement_text = r"</br><h3>Real-Time Bug and Issue Fixes</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Time and Cost Efficiency$'
                replacement_text = r"</br><h3>Time and Cost Efficiency</h3></br>"
                # Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                pattern = r'^Paragraph 1 Heading$'
                replacement_text = r"</br>"
                #Replace the matched lines with the replacement text
                blogdet = re.sub(pattern, replacement_text, blogdet, flags=re.MULTILINE)

                #econde html tags
                #blogdet = html.escape(blogdet)
                

                print("Blogdet replaced::::")
                print(blogdet)
                BlogSummary.find_one_and_update({"_id":converted_id},{"$set":{"blog_det":blogdet,"url":url}})

    
        
    
    return {"status": "success", "msg": "blog detail created"}


# @router.post("/createblogimage")
# def create_image():
#     #create image
#     cr = Computerender("sk_aBIr16LFau4ZgKjER1b-S")
#     #cr.api_key = "sk_aBIr16LFau4ZgKjER1b-S"

#     img_bytes = asyncio.run(
#         cr.generate(
#         "Show a group of diverse developers collaborating with Code Genie, optimizing their code together", w=422, h=294
#     ))

#     # optionally write to file
#     with open("static/result.jpg", "wb") as f:
#         f.write(img_bytes)


@router.get("/listBlogs")
async def get_blogs(cat: str="cat1", limitval: int = 12, skipval: int = 0):
    print("limitval....")
    print(limitval)
    blogs = BlogSummary.find({"cat":cat}).limit(limitval).skip(skipval);
    blogs = list(blogs)
    blogs = blogsEntity(blogs)
    return {"status": "success", "data": blogs}

@router.get("/listBlogsadmin")
async def get_blogs(limitval: int, skipval: int, query: str = None):
    if str(limitval == ""): limitval=10
    if str(skipval) == "": skipval=0
    blogs = ""
    recordCount = 0
    if (query=="" or query == None):
        blogs = BlogSummary.find({}).limit(limitval).skip(skipval)
        recordCount = BlogSummary.count_documents({})
    else:
        blogs = BlogSummary.find({"blog_title":{"$regex":query}}).limit(limitval).skip(skipval)
        recordCount = BlogSummary.count_documents({"blog_title":{"$regex":query}})
    blogs = list(blogs)
    blogs = blogsEntity(blogs)
    return {"status": "success", "data": blogs, "recordCount": recordCount}

@router.get("/listBlogsCount")
async def get_blogs_count(query: str = None,cat: str=None):
    fltquery = {};
    if(cat!="" and cat != None):
        fltquery["cat"] = cat;
    if (query!="" and query != None):
        fltquery["blog_title"] = {"$regex":query}
    

    recordCount = BlogSummary.count_documents(fltquery)
        

   
    return {"status": "success", "data": recordCount}


@router.get("/getPromptDet")
async def get_prompt_det(product_id: str):
    prompts = Prompts.find({"product_id":ObjectId(product_id),"prompt_name":"CTA"});
    prompts = list(prompts)
    prompts = blogsEntity(prompts)
  
    
    return {"status": "success", "data": prompts}


@router.get("/getBlogDet")
async def get_blogs_det(blog_id: str):
    blogs = BlogSummary.find({"_id":ObjectId(blog_id)});
    blogs = list(blogs)
    blogs = blogsEntity(blogs)
  
    
    return {"status": "success", "data": blogs}


@router.get("/getBlogDetbyURL")
async def get_blogs_det(url: str):
    print("url......*****")
    print(url)
    blogs = BlogSummary.find({"url":url}).skip(0).limit(1)
    blogs = list(blogs)
   
    blog = ""
    productid = ""
    if len(blogs) > 0:
        blog = blogs[0]
        if "product_id" in blog:
            productid = blog["product_id"]
    else:
        #return empty content
        print("empty content")
        return {"status": "success", "data": ''}
    
    blogs = blogsEntity(blogs)



    #update views count
    BlogSummary.find_one_and_update({"url":url},{"$inc":{"total_views":1}})

    found  = 0
    nexturl = ""
    index = 0
    firsturl = ""
    keyword = ""
    dbKeyword = ""
    cta = ""
    
    #get the next blog url using prompt id
    if "prompt_id" in blog and productid != "":
        print("prompt id.............")
        print(blog['prompt_id'])
        #get the keyword
        result =   Prompts.find({"_id":ObjectId(blog['prompt_id'])})
        seo_line = ""
        for prompt in result:
            if "keyword"  in prompt:
                keyword = prompt["keyword"]
                dbKeyword = prompt["keyword"]
            elif ":" in prompt["prompt"]:
                keyword = prompt["prompt"].split(":")[0]
                if "/" in keyword:
                    keyword = keyword.split('/')[0]
                #keyword = "Code Genie audit "+keyword+"  smart contract."
            else:
                if "keyword" in prompt:
                    keyword = prompt["keyword"]
                    dbKeyword = prompt["keyword"]
                    seo_line = prompt["seo_line"]
                else:
                    keyword = prompt["prompt"]
                    dbKeyword = prompt["prompt"]
                #keyword = seo_line.replace("{keyword}",keyword)
        
        #get the next blog url using prompt id
        result1 =   Prompts.find({"product_id":ObjectId(productid),"prompt_name":"CTA"})
        for prompt1 in result1:
            cta = prompt1["prompt"]
            # Regular expression pattern to match the URL
            pattern = r'URL:\s*"([^"]+)"'
            # Search for the URL in the input string
            match = re.search(pattern, cta)
            if match:
                # If URL found, extract the URL without quotes
                url = match.group(1)
                print("URL found:", url)

                # Split the input string using the URL
                parts = cta.split(f'URL: "{url}"')

                # Get the remaining string after splitting
                cta = url
                print("Remaining string:", cta)

        
        BlogList = BlogSummary.find({"prompt_id":ObjectId(blog['prompt_id']),"flag":1}).sort("_id",-1)
        BlogList = list(BlogList)

        print("==============")
        print(keyword)

        for nxblog in BlogList:
            
            if index == 0:
                firsturl = nxblog['url']
                #firsturl = keyword+"::"+nxblog['url']
            if found == 1:
                nexturl = nxblog['url']
                #nexturl = keyword+"::"+nxblog['url']
                break
            if nxblog['url']==url:
                found = 1


            index = index + 1

    #if no next url found, assing first url in the list           
    if found == 0 or index == len(BlogList):
        if keyword in firsturl:
            nexturl = firsturl
        else:
            nexturl = firsturl
            #nexturl = keyword+"::"+firsturl


    #do some cleanup work
    pattern = r'"'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    #do some cleanup work
    pattern = r'^Keywords:(.)*\n$'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    #do some cleanup work
    pattern = r'^Keywords:(.)*$'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    pattern = r'^(-)+\n$'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    pattern = r'^</br><h3>Blog Article</h3></br>$'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    pattern = r'Title:'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    
    pattern = r'</br><h3></h3></br>'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    pattern = r'</br><h3> </h3></br>'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)


    pattern = r'\*\*Paragraph [0-9] Heading:'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

    pattern = r'#+'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)


    pattern = r'\*+'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)

     
    pattern = r'\btitle:'
    replacement_text = r""
    # Replace the matched lines with the replacement text
    blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)


    print("nexturl...........")
    print(nexturl)
    # Create a case-insensitive pattern
    pattern = re.compile(re.escape(keyword), re.IGNORECASE)
    # Replace the first occurrence
    if pattern.search(blogs[0]["blog_det"]) and dbKeyword != "":
        print("inside search.....")
        print(keyword)
        blogs[0]["blog_det"]  = pattern.sub(
            f"<a target='_blank' href='{nexturl}'>{keyword}</a> ",
            blogs[0]["blog_det"],
            count=1
        )

     #add external link for Robotics
    pattern = re.compile(re.escape("Robotics"), re.IGNORECASE)
    # Replace the first occurrence
    if pattern.search(blogs[0]["blog_det"]):
        print("inside search.....")
        print("Robotics")
        blogs[0]["blog_det"]  = pattern.sub(
            f"<a target='_blank' href='https://en.wikipedia.org/wiki/Robotics'>Robotics</a> ",
            blogs[0]["blog_det"],
            count=1
        )

    #add external link for artificial intelligence
    pattern = re.compile(re.escape("artificial intelligence"), re.IGNORECASE)
    # Replace the first occurrence
    if pattern.search(blogs[0]["blog_det"]):
        print("inside search.....")
        print("artificial intelligence")
        blogs[0]["blog_det"]  = pattern.sub(
            f"<a target='_blank' href='https://en.wikipedia.org/wiki/Artificial_intelligence'>artificial intelligence</a> ",
            blogs[0]["blog_det"],
            count=1
        )

    print("blog details ...........")
    print(blogs[0]["blog_det"])
    # #add hyper link for keyword
    # pattern = r'</br><h3> </h3></br>'
    # replacement_text = "<a target='_blank' href='"+nexturl+"'>"+keyword+"</a>"
    # blogs[0]["blog_det"] = re.sub(keyword, f"<a target='_blank' href='{nexturl}'>{keyword}</a>", blogs[0]["blog_det"], flags=re.IGNORECASE)
    # #blogs[0]["blog_det"] = re.sub(pattern, replacement_text, blogs[0]["blog_det"], flags=re.MULTILINE)


    return {"status": "success", "data": blogs, "nexturl":keyword+"::"+nexturl+"::"+cta}

@router.get("/createSiteMap") 
async def createSiteMap(prompt_ids: str):
    import datetime
    # Load the XML file
    #tree = ET.parse('sitemap/sitemapnew.xml') 
    #root = tree.getroot()

    prompt_ids_list = prompt_ids.split(",")

    consolidated_file_path = 'static/consolidated.xml'


    # Loop through each ID and get details
    with open(consolidated_file_path, 'w') as rootfile:

        for prompt_id in prompt_ids_list:  
        
            blogs = BlogSummary_live.find({"flag":{"$in":[1,4]},"prompt_id":ObjectId(prompt_id)})
            blogs = list(blogs)
            keyword_name =  ""

            result =   Prompts.find({"_id":ObjectId(prompt_id),"prompt_name":"CATEGORY"}) 
            if not result:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Something went wrong",
                )
            else:
                for prompt in result:
                    print(prompt['_id'])
                    print(prompt['product_id'])
                    print(prompt["prompt"])
                    print("\n")
                    #keyword = prompt["prompt"].split(":")[0];
                    keyword = prompt["keyword"];
                    # Append the date to the original file name
                    keyword_name =  re.sub(r'\b', '_', keyword)  
            

            file_path = 'static/'+keyword_name+'.xml' 

        
            indexcnt = 0

            
            with open(file_path, 'w') as file:
                file.write("""<?xml version="1.0" encoding="UTF-8"?>\r\n<urlset
            xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
                    http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">\r\n""")
                for blogdet in blogs:
                    indexcnt = indexcnt + 1
                    print("""indexcnt"""+str(indexcnt))
                    if len(blogdet) > 0:
                        print("""Index::: """+str(blogdet["url"]))
                        current_datetime = datetime.datetime.now()
                        formatted_datetime = current_datetime.strftime('%Y-%m-%dT%H:%M:%S+00:00')
                        url = quote(blogdet["url"])
                        
                        file.write("""\r\n<url>
                            <loc>https://code-genie.ai/blogs/"""+url+"""</loc>
                            <lastmod>"""+formatted_datetime+"""</lastmod>
                            </url>\r\n""")
                file.write("""</urlset>""");  
        

            current_datetime = datetime.datetime.now()
            formatted_datetime = current_datetime.strftime('%Y-%m-%dT%H:%M:%S+00:00')
            rootfile.write("""\r\n<url>
                <loc>https://code-genie.ai/"""+keyword_name+""".xml</loc>
                <lastmod>"""+formatted_datetime+"""</lastmod>
                </url>""")

@router.post("/updateblog")
def update_blog(payload: BlogSummarySchema):
    

    id = payload.id
    blog_title = payload.blog_title
    blog_summary = payload.blog_summary
    blog_det = payload.blog_det
    url = payload.url
    blog_image_path = payload.blog_image

    reply = {}

    blogs = BlogSummary.find_one_and_update(
                    {"_id":ObjectId(id)},
                    {"$set":{"blog_title":blog_title, "blog_summary": blog_summary, 
                             "blog_det": blog_det, "url": url, "blog_image_path": blog_image_path}}
                )
    
    return {"status": "success", "msg": "Record updated successuflly."}


@router.get("/deleteBlog")
async def delete_blog(blog_id: str):
    BlogSummary.delete_one({"_id":ObjectId(blog_id)});
    blogs = BlogSummary.find_one({"_id":ObjectId(blog_id)});
    print(blogs)
    if blogs:
        return {"status": "failed", "data": "Something went wrong, try again later"}
    else:
        return {"status": "success", "data": "Blog deleted successfully"}
    
@router.post("/extractDoc")
def read_word_pdf_file(file: UploadFile = File(...), product_name: str = Form(...), product_module: str = Form(...), 
                       blog_count: int = Form(...), seo_line: str = Form(...)):
    

    if file is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Please upload file"
        )
    elif product_name == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Product Name"
        )
    elif product_module == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Product Module"
        )
    elif blog_count<=0:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Blog Count"
        )
    
     # Check file extension
    if not allowed_file_size(file.size):
        raise HTTPException(status_code=400, detail="File size exceeds the maximum allowed size (1 MB)")
    
    #get the product id from product table
    existing = Products.find_one({"product_name": product_name,"product_module":product_module})
    productid = ""
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="Produt name or module not found"
        )
    else:
        productid = existing["_id"]

    print(f"_id:{productid}")

    # Save the file
    file_name = file.filename
    with open(f"./static/{file_name}", "wb") as f:
        f.write(file.file.read())

    #read file
    ext = file_name.rsplit('.', 1)[1].lower()

    file_path = f"./static/{file_name}"

    full_text = []

    if ext=="docx":
        doc = Document(file_path)
        

        for para in doc.paragraphs:
            full_text.append(para.text)
            print(para.text)
            


    if ext=="pdf":
        pdf_document = fitz.open(file_path)
        full_text = []
        for page_number in range(pdf_document.page_count):
            page = pdf_document[page_number]
            print(page.get_text())
            # Get the text of the page
            page_text = page.get_text()

            # Split the text into lines
            lines = page_text.split('\n')

             # Process each line
            for line_number, line in enumerate(lines, start=1):
                print(f"Page {page_number + 1}, Line {line_number}: {line}")
                full_text.append(line)

    if ext == "csv":
        # Open the CSV file in read mode
        with open(file_path, 'r') as csvfile:
            # Create a CSV reader object
            csv_reader = csv.reader(csvfile)

            # Iterate over each row in the CSV file
            for row in csv_reader:
                # Each row is a list of values
                print(row[1]+"::"+row[2])
                full_text.append(row[1]+"::"+row[2])

    
    #insert all categories into db
    for element in full_text:
        print(element)
        #Insert each line into db for further blog generation processing
        if element.strip()!="":
            values = element.split("::")
            Prompts.find_one_and_update(
                    {"product_id":ObjectId(productid),"prompt_name": "CATEGORY","prompt": values[0]},
                    {
                        "$set":
                        {
                            "product_id":ObjectId(productid),
                            "prompt_name": "CATEGORY",
                            "prompt": values[0],
                            "order": blog_count,
                            "completed_count":0,
                            "processed":False,
                            "keyword": values[1],
                            "seo_line": seo_line
                        }
                    },
                    upsert=True
            )


   
    return {"status": "success", "msg": "File uploaded successuflly."}

    # Replace 'your_word_file.docx' with the path to your Word file
    # word_file_path = 'your_word_file.docx'
    # content = read_word_file(word_file_path) 


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def allowed_file_size(file_size):
    if file_size > MAX_FILE_SIZE:
        return False
    else:
        return True


@router.get("/createblogimageUsingUnsplash")
def create_image_from_unsplash():
    # Initialize the Unsplash API client
    #access_key = '22J-X11dByQm8m7e0aDsb6RyEIUK2RqxdGwfErP9-5Q'
    application_secret = 'LtsesV-WDvcVyewRXz-4x-leDHLHYIufqBYP8p2lMZI'
    callback_url = 'urn:ietf:wg:oauth:2.0:oob'
    utm_source = 'CODE-GENIE TEST'

    # Specify the URL you want to send the GET request to
    #url = f'https://api.unsplash.com/search/photos/?query={query}&client_id={access_key}'
    # Initialize the S3 client
    s3 = boto3.client('s3')

    # Specify your S3 bucket name and the name you want to give to the uploaded image
    bucket_name = 'uiassetbucket'
    image_name = 'example.jpg'  # Change to the name you want
    # Specify your AWS credentials manually (not recommended)
    aws_access_key_id = 'AKIAUMLQOJ7A2A62DXNZ'
    aws_secret_access_key = 'y7GIeRf71WwnRWbFDrHUU9wlMvmBN4KsnHjrmZ8Z'

    blogsummaries = BlogSummary.find({'image_updated':{"$in":[None,'No']},'flag':1}).limit(10)
    #blogsummaries = BlogSummary.find({"cat": cat,'image_updated':{"$in":['Yes']}}).limit(limit)
    blogsummaries = list(blogsummaries)
    index = 0
    for blogsummary in blogsummaries:
        index = index + 1

        print("image string::::::::::::")
        print(blogsummary)

        # Original string with special characters
        original_string = blogsummary["blog_image_string"]
        # Encode the string
        encoded_string = urllib.parse.quote(original_string)

        blogid = blogsummary["_id"]

        print('blogid****:::::::')
        print(blogid)

        url = 'https://api.unsplash.com/search/photos/?count=1,query='+encoded_string+'&client_id=Nkd9ETdHykSsAkogdhW8q-SdCvX0qNSRd8VzabeIgm0'

        # Initialize the S3 client with the credentials
        s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)

        image_url = get_image_from_unsplash(encoded_string, 'Nkd9ETdHykSsAkogdhW8q-SdCvX0qNSRd8VzabeIgm0', blogid)

      
        ### s3 upload section starts 
        # # Download the image
        # image_response = requests.get(image_url[0]) #get bigger image
        # if image_response.status_code == 200:
        #     with open('./static/test/downloaded_image.jpg', 'wb') as file:
        #         file.write(image_response.content)
        #         print('Image downloaded successfully.')
        # else:
        #     print('Failed to download image.')

        # # Download the image
        # image_response_smaller = requests.get(image_url[1]) #get bigger image
        # if image_response_smaller.status_code == 200:
        #     with open('static/test/downloaded_image_small.jpg', 'wb') as file:
        #         file.write(image_response_smaller.content)
        #         print('Image downloaded successfully.')
        # else:
        #     print('Failed to download image.')
    
        # # Specify the local file path to the image you want to upload
        # local_file_path = 'static/test/downloaded_image.jpg'
        # local_file_path_small = 'static/test/downloaded_image_small.jpg'

        # object_name = 'smartcontract/images/'+str(blogid)+'.jpg'  # You can specify a different path and file name

        # # Upload the image to the S3 bucket
        # s3.upload_file(local_file_path, bucket_name, object_name, ExtraArgs={'ContentDisposition': 'image/jpeg'})

        # object_name_small = 'smartcontract/images/'+str(blogid)+'_small.jpg'  # You can specify a different path and file name

        # # Upload the small image to the S3 bucket
        # s3.upload_file(local_file_path_small, bucket_name, object_name_small, ExtraArgs={'ContentDisposition': 'image/jpeg'})

        ### s3 upload section ends

        blogs = BlogSummary.find_one_and_update(
            {"_id":ObjectId(str(blogid))},
            {"$set":{"image_updated":"Yes", "blog_image_path": image_url[0], "blog_image_path_small":  image_url[1]}}
        )

    return {"status": "success", "msg": "image created"}

def get_image_from_unsplash(encoded_string, access_key,  blog_id):  
    url = 'https://api.unsplash.com/photos/random?query='+encoded_string+'&client_id='+access_key
    print(url)
    #check image id already exist in db or not
    uniqueimagefound = False
    retrycount = 0
    while(uniqueimagefound == False and retrycount <=2):
        if retrycount > 2 :
            retrycount = 0
        # Send the GET request
        response = requests.get(url)
        print("response:::::::::::::")
        print(response)
        # Parse the JSON response to access the image URLs
        data = response.json()
        # Get the first photo from the search results
        print("\r\n\r\nData:::")
        print(data)
        print("\r\n\r\n")
        #get result from unsplash and 
        if data:
            photo = data
            print("photo:::::::\r\n\r\n")
            print(photo)
            imgid = photo['id']
            blogsummaries = BlogSummary.find({"image_original_id": imgid}).limit(1)
            blogsummaries = list(blogsummaries)
            print("\r\n\r\nrecordCount:::"+str(imgid))
            print(len(blogsummaries))
            print("\r\n\r\nblog_id:::"+str(blog_id))
            if len(blogsummaries) > 0:
                uniqueimagefound = False
                if retrycount == 2:
                    retrycount = retrycount + 1
                    uniqueimagefound = True 
                    # Modify the URL to specify the desired size
                    image_url = f"{photo['urls']['raw']}?w=1152&h=350" #bigger
                    image_url1 = f"{photo['urls']['raw']}?w=453&h=191" #smaller
                    blogs = BlogSummary.find_one_and_update(
                        {"_id":ObjectId(str(blog_id))},
                        {"$set":{"image_original_id":imgid}}
                    )
                    break    
                retrycount = retrycount + 1
            else:
                uniqueimagefound = True 
                # Modify the URL to specify the desired size
                image_url = f"{photo['urls']['raw']}?w={1152}&h={350}" #bigger
                image_url1 = f"{photo['urls']['raw']}?w={453}&h={191}" #smaller
                blogs = BlogSummary.find_one_and_update(
                    {"_id":ObjectId(str(blog_id))},
                    {"$set":{"image_original_id":imgid}}
                )
                break
        time.sleep(10) 
    return [image_url,image_url1]
    # optionally write to file
    #with open("static/result.jpg", "wb") as f:
    #    f.write(img_bytes)
            
# @router.get("/createblogimageAPI")
# def create_image_from_unsplash(blogid: str):
#     # Initialize the Unsplash API client
#     #access_key = '22J-X11dByQm8m7e0aDsb6RyEIUK2RqxdGwfErP9-5Q'
#     application_secret = 'LtsesV-WDvcVyewRXz-4x-leDHLHYIufqBYP8p2lMZI'
#     callback_url = 'urn:ietf:wg:oauth:2.0:oob'
#     utm_source = 'CODE-GENIE TEST'

#     # Specify the URL you want to send the GET request to
#     #url = f'https://api.unsplash.com/search/photos/?query={query}&client_id={access_key}'
#     # Initialize the S3 client
#     s3 = boto3.client('s3')

#     # Specify your S3 bucket name and the name you want to give to the uploaded image
#     bucket_name = 'uiassetbucket'
#     image_name = 'example.jpg'  # Change to the name you want
#     # Specify your AWS credentials manually (not recommended)
#     aws_access_key_id = 'AKIAUMLQOJ7A2A62DXNZ'
#     aws_secret_access_key = 'y7GIeRf71WwnRWbFDrHUU9wlMvmBN4KsnHjrmZ8Z'

#     blogsummaries = BlogSummary.find({"_id":ObjectId(str(blogid))}).limit(1)
#     #blogsummaries = BlogSummary.find({"cat": cat,'image_updated':{"$in":['Yes']}}).limit(limit)
#     blogsummaries = list(blogsummaries)
#     print(blogsummaries)
#     index = 0
#     for blogsummary in blogsummaries:
#         index = index + 1

#         access_key = "Nkd9ETdHykSsAkogdhW8q-SdCvX0qNSRd8VzabeIgm0"

#         print("image string::::::::::::")
#         print(blogsummary)

#         # Original string with special characters
#         original_string = blogsummary["blog_image_string"]
#         # Encode the string
#         encoded_string = urllib.parse.quote(original_string)

#         blogid = blogsummary["_id"]

#         print('blogid****:::::::')
#         print(blogid)

#         url = 'https://api.unsplash.com/search/photos/?count=1,query='+encoded_string+'&client_id='+access_key

#         # Initialize the S3 client with the credentials
#         s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)

#         image_url = get_image_from_unsplash(encoded_string, access_key, blogid)

      
#         # Download the image
#         image_response = requests.get(image_url[0]) #get bigger image
#         if image_response.status_code == 200:
#             with open('static/test/downloaded_image.jpg', 'wb') as file:
#                 file.write(image_response.content)
#                 print('Image downloaded successfully.')
#         else:
#             print('Failed to download image.')

#         # Download the image
#         image_response_smaller = requests.get(image_url[1]) #get bigger image
#         if image_response_smaller.status_code == 200:
#             with open('static/test/downloaded_image_small.jpg', 'wb') as file:
#                 file.write(image_response_smaller.content)
#                 print('Image downloaded successfully.')
#         else:
#             print('Failed to download image.')
    
#         # Specify the local file path to the image you want to upload
#         local_file_path = 'static/test/downloaded_image.jpg'
#         local_file_path_small = 'static/test/downloaded_image_small.jpg'

#         object_name = 'smartcontract/images/'+str(blogid)+'.jpg'  # You can specify a different path and file name

#         # Upload the image to the S3 bucket
#         s3.upload_file(local_file_path, bucket_name, object_name, ExtraArgs={'ContentDisposition': 'image/jpeg'})

#         object_name_small = 'smartcontract/images/'+str(blogid)+'_small.jpg'  # You can specify a different path and file name

#         # Upload the small image to the S3 bucket
#         s3.upload_file(local_file_path_small, bucket_name, object_name_small, ExtraArgs={'ContentDisposition': 'image/jpeg'})

#         blogs = BlogSummary.find_one_and_update(
#             {"_id":ObjectId(str(blogid))},
#             {"$set":{"image_updated":"Yes", "blog_image_path": object_name, "blog_image_path_small": object_name_small}}
#         )

#     return {"status": "success", "msg": "image created"}


def get_image_from_unsplash(encoded_string, access_key,  blog_id):  
    url = 'https://api.unsplash.com/photos/random?query='+encoded_string+'&client_id='+access_key

    print(url)
    #check image id already exist in db or not
    uniqueimagefound = False
    retrycount = 0
    while(uniqueimagefound == False and retrycount <=10):
        if retrycount > 10 :
            retrycount = 0
        # Send the GET request
        response = requests.get(url)
        #print("response:::::::::::::")
        #print(response)
        # Parse the JSON response to access the image URLs
        data = response.json()
        # Get the first photo from the search results
        #print("\r\n\r\nData:::")
        print(blog_id)
        print("\r\n\r\n")
        #get result from unsplash and 
        if data:
            photo = data
            print("photo:::::::\r\n\r\n")
            print(photo)
            imgid = photo['id']
            blogsummaries = BlogSummary.find({"image_original_id": imgid}).limit(1)
            blogsummaries = list(blogsummaries)
            print("\r\n\r\nrecordCount:::"+str(imgid))
            print(len(blogsummaries))
            print("\r\n\r\nblog_id:::"+str(blog_id))
            if len(blogsummaries) > 0:
                uniqueimagefound = False
                if retrycount == 10:
                    retrycount = retrycount + 1
                    uniqueimagefound = True 
                    # Modify the URL to specify the desired size
                    image_url = f"{photo['urls']['raw']}?w=1152&h=350" #bigger
                    image_url1 = f"{photo['urls']['raw']}?w=453&h=191" #smaller
                    blogs = BlogSummary.find_one_and_update(
                        {"_id":ObjectId(str(blog_id))},
                        {"$set":{"image_original_id":imgid}}
                    )
                    break    
                retrycount = retrycount + 1
            else:
                uniqueimagefound = True 
                # Modify the URL to specify the desired size
                image_url = f"{photo['urls']['raw']}?w={1152}&h={350}" #bigger
                image_url1 = f"{photo['urls']['raw']}?w={453}&h={191}" #smaller
                blogs = BlogSummary.find_one_and_update(
                    {"_id":ObjectId(str(blog_id))},
                    {"$set":{"image_original_id":imgid}}
                )
                break

        time.sleep(60) 

    return [image_url,image_url1]

@router.get("/get_image_from_unsplash")
def get_image_url():

    blogsummaries = BlogSummary.find({"image_updated":'Yes',"flag":{"$ne":4}},{"image_original_id":1,"_id":0})
    blogsummaries = list(blogsummaries)
    print(blogsummaries)
    index = 0
    for blogsummary in blogsummaries:
        # Original string with special characters
        original_id = blogsummary["image_original_id"]
        print(original_id)
        url = f'https://api.unsplash.com/photos/{original_id}'
        print(url)
        headers = {'Authorization': f'Client-ID Nkd9ETdHykSsAkogdhW8q-SdCvX0qNSRd8VzabeIgm0'}

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()  # Raise an error for bad responses

            data = response.json()
            image_url = data['urls']['full']  # or data['urls']['regular'], data['urls']['small'], etc.
            small_image_url =  image_url + f'?w=453&h=191'
            BlogSummary.update_many({"image_original_id":original_id},{"$set":{"flag":4, "blog_image_path":image_url,"blog_image_path_small":small_image_url,"blog_image_path_draft":image_url}})
        
            print(image_url)
            #return image_url

            # Sleep for 10 seconds
            if((index%50)==0 and index>49):
                time.sleep(600)

            index = index + 1

        except requests.exceptions.RequestException as e:
            print(f"Error fetching image URL for {original_id}: {e}")
            time.sleep(600)
            continue  # Skip to the next iteration of the loop


@router.get("/export_seo_csv")
async def export_seo_csv(prompt_ids: str):

    prompt_ids_list = prompt_ids.split(",")

    # Loop through each ID and get details
    for prompt_id in prompt_ids_list:   
        #result =   Prompts.find({"prompt_name":"CATEGORY","_id":ObjectId('654efc43ec93a2f28ebe4a29')})
        print("prompt_id:",prompt_id)
        result =   Prompts.find({"_id":ObjectId(prompt_id),"prompt_name":"CATEGORY","processed":True,"seo_url":{"$in":[None,'Yes','No']}})
        if not result:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Something went wrong",
            )
        else:
            for prompt in result:
                print(prompt['_id'])
                print(prompt['product_id'])
                print(prompt["prompt"])
                print("\n")
                #keyword = prompt["prompt"].split(":")[0];
                keyword = prompt["keyword"];
                # Append the date to the original file name
                keyword_name =  re.sub(r'\b', '_', keyword)  
                Prompts.find_one_and_update({"_id":ObjectId(prompt['_id'])},{"$set":{"seo_url":'Yes'}})
                #check prompt is exists or not in the blog summary
                blogs = BlogSummary.find({"prompt_id":ObjectId(prompt['_id'])})
                if blogs:
                    # Specify the file path
                    file_path = 'static/'+keyword_name+'_output.csv'
                    # # Writing to CSV file
                    with open(file_path, 'w') as file:
                        for blog in blogs:
                            if 'url' in blog:
                                #print(blog['url'])
                                #print("\n")
                                if "/" in keyword:
                                    keyword = keyword.split('/')[0]
                                file.write(keyword+",https://code-genie.ai/blogs1/"+blog['url']+'\n')
                print("\n")



@router.get("/extract_urls_from_sitemap")
def extract_urls_from_sitemap():
    import xml.etree.ElementTree as ET
    try:
        # Parse the XML file
        xml_file_path = "static/sitemapnew.xml"
        tree = ET.parse(xml_file_path)
        root = tree.getroot()

        # Extract URLs from the XML
        urls = [url.text for url in root.findall(".//{http://www.sitemaps.org/schemas/sitemap/0.9}loc")]

        # Replace 'path/to/sitemap.xml' with the actual path to your sitemap.xml file
        sitemap_path = 'static/sitemapnew.xml'
        final_url_list="";
        if urls:
            print("Extracted URLs:")
            for url in urls:
                final_url_list = final_url_list + "'" + url.replace("https://www.code-genie.ai/blogs/","") + "',"
                print(url)
        else:
            print("Failed to extract URLs.")

    

    except Exception as e:
        print(f"Error: {e}")
        return None
    
        
    return {"status": "success", "urllsit": final_url_list}

    
    

# @router.get("/test_api")
# def test_api(promptmsg, access_key,  blog_id): 
#     openai.api_key = "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"

#     # Create a completion request
#     response = openai.ChatCompletion.create(
#     model="gpt-4-1106-preview",
#     messages = [
#       {
#         "role": "system",
#         "content": "You are a helpful assistant."
#       },
#       {
#         "role": "user",
#         "content": promptmsg
#       },
#     ],
#     max_tokens=10000,
#     temperature=0.7
#     )

#     # Extract the generated text from the response
#     generated_text = response.choices[0].message

#     # Print the generated text
#     print(generated_text)

#     return {"status": "success", "msg": generated_text}


# @router.get("/embedding_test")
# def embed_test(msg):
    
#     import pinecone
#     import torch
#     from transformers import AutoModel, AutoTokenizer

#     # Define your Pinecone API key and index name
#     api_key = "f18c57a4-91de-43cc-993a-abc92278de28"
#     index_name = "opoenai"

#     # Connect to Pinecone
#     pinecone.init(api_key=api_key, environment="gcp-starter")

#     # check if 'openai' index already exists (only create index if not)
#     if index_name not in pinecone.list_indexes():
#         pinecone.create_index(index_name, dimension=768)
#         # connect to index

  
#     index = pinecone.Index(index_name)

#     # Load a pre-trained BERT model and tokenizer
#     model_name = "bert-base-uncased"
#     tokenizer = AutoTokenizer.from_pretrained(model_name)
#     model = AutoModel.from_pretrained(model_name)

#     # Data you want to upsert
#     data = [{"id": "doc1", "text": msg}]

   
#     # Convert text data to embeddings and upsert into the Pinecone index
#     for item in data:
#         text = item["text"]
#         input_ids = tokenizer.encode(text, return_tensors="pt", padding=True, truncation=True)
        
#         with torch.no_grad():
#             embeddings = model(input_ids).last_hidden_state.mean(dim=1).tolist()
#         vector_data = embeddings[0]

#         #print(vector_data)
#         # Upsert the data into the Pinecone index
#         index.upsert(vectors=[(item["id"], vector_data)])



#     # Query a new text
#     query_text = "Provide summary of the code"
#     query_input_ids = tokenizer.encode(query_text, return_tensors="pt", padding=True, truncation=True)
#     with torch.no_grad():
#         query_embeddings = model(query_input_ids).last_hidden_state.mean(dim=1).tolist()
#     query_vector_data = query_embeddings[0]
#     #print(query_vector_data)

#     # Perform a similarity search
#     results = index.query(vector=query_vector_data,top_k=1,include_values=True)

#     #print(results)

#     # Convert vector data into text or prompts (as per GPT-3.5-turbo requirements)
#     prompts = [f"Provide summary of the code{i}: {vector}" for i, vector in enumerate(vector_data)]

#     # Define your GPT-3.5-turbo prompt
#     gpt3_prompt = (
#         "Provide summary of the code{:\n"
#         + "\n".join(prompts)
#     )

#     print("----------------------------------")
#     print(gpt3_prompt)

#     # Use GPT-3.5-turbo to run the prompt
#     response = openai.Completion.create(
#         engine="text-davinci-003",
#         prompt=gpt3_prompt,
#         max_tokens=100,  # Adjust as needed
#         n=1,             # Generate 1 response
#         stop=None,       # You can specify a stop condition
#         temperature=0.7,  # Adjust temperature for creativity
#     )

#     print(response)

# @router.get("/create_embedding")
# def test_api(promptmsg, access_key,  blog_id): 

#      # Load the Langchain text splitter
#      from langchain import text_splitter
#      from langchain.text_splitter import SentenceTransformersTokenTextSplitter
#      import numpy as np
 
#      with open("./lng_output.txt","w") as f:
#         f.write(promptmsg)

#      #document loader
#      from langchain.document_loaders import TextLoader
#      loader = TextLoader("./lng_output.txt")
#      documents =  loader.load()

#      #Text spiliter
#      from langchain.text_splitter import CharacterTextSplitter
#      text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
#      docs = text_splitter.split_documents(documents)

#      #Embeddings
#      from langchain.embeddings import HuggingFaceEmbeddings
#      embeddings = HuggingFaceEmbeddings()

#      #Vector store 
#      from langchain.vectorstores import faiss

#      db = faiss.FAISS.from_documents(docs, embeddings)

#      query = "Provide summary of the code"
#      docs = db.similarity_search(query)

#      print(docs[0].page_content)

#      # Prepare data for upsert
#      #data = [{"id": f"doc_{i}", "vector": vector_data[i]} for i in range(len(vector_data))]

#      blog_id = "blog_001"

#      # Initialize Pinecone client
#      pinecone.init(api_key="f18c57a4-91de-43cc-993a-abc92278de28", environment="gcp-starter")

#      # Upsert the data into the Pinecone index
#      #pinecone.upsert(index_name='openai', items=[{"id": blog_id, "vector": vector_data}])


#      # check if 'openai' index already exists (only create index if not)
#      #if 'openai' not in pinecone.list_indexes():
#      #   pinecone.create_index('openai', dimension=1536)
#         # connect to index
        
#      index = pinecone.Index('openai')

#      #print(data)    

#      # Upsert the data into the Pinecone index
#      #index.upsert()
#      #print("-------------")
#      #print(data[0]['vector'])
#      ##vector_id = 0
#      ##data = {'vectors':vector_data[0] }
#      ##index.upsert({"vectors": vector_data})
#      ##vector_id = vector_id + 1



     
# #     MODEL = "text-embedding-ada-002"

    
# #     # Initialize the CodeVectorGenerator if required
# #     generator = CodeVectorGenerator()
# #     # Generate vector representation for a code snippet
# #     vectors = generator.generate_vector(promptmsg)

# #     print(vectors)

# #     # Initialize Pinecone client
# #     pinecone.init(api_key="f18c57a4-91de-43cc-993a-abc92278de28", environment="gcp-starter")

# #     # check if 'openai' index already exists (only create index if not)
# #     if 'openai' not in pinecone.list_indexes():
# #         #pinecone.create_index('openai', dimension=len(embeds[0]))
# #         pinecone.create_index('openai', dimension=1536)
# #     # connect to index
# #     index = pinecone.Index('openai')

# #     # Store the vector representations in Pinecone
# #     vector_id = 0
# #     for vector in vectors:
# #         index.upsert(vector_id=str(vector_id), vector=vector)
# #         vector_id = vector_id + 1

# #     #pinecone.delete_index('openai')

# # @router.get("/search_embed")
# # def test_api(promptmsg):
# #     MODEL = "text-embedding-ada-002"

# #     response = openai.Embedding.create(
# #         engine=MODEL,
# #         input=[promptmsg],
# #     )

    
# #     # Initialize Pinecone client
# #     pinecone.init(api_key="f18c57a4-91de-43cc-993a-abc92278de28", environment="gcp-starter")

# #     query = "Provide summary of the code."

# #     index = pinecone.Index("openai")   

# #     xq = openai.Embedding.create(input=query, engine=MODEL)['data'][0]['embedding']
# #     res = index.query([xq], top_k=1, include_metadata=True)

# #     print(res)

# @router.get("/langchian-test")
# def test_api(promptmsg): 
#     import os
#     os.environ['OPEN_API_KEY']= "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"

#     from langchain.llms import OpenAI
#     llm = OpenAI(temperature=0.7)
#     msg = llm("I want to open a restaurant for Indian food. Suggest fancy name")

#     from langchain.prompts import PromptTemplate

#     prompt_template_summary = PromptTemplate(
#         input_variables = ['msg'],
#         template = "Please provide the summary of blow codee: {msg}."
#     )

    
#     prompt_template_analyze = PromptTemplate(
#         input_variables = ['msg'],
#         template = """[follow the steps below in the order listed.  
# 	1. Write "This output identifies any bugs or errors in the code and tries to fix any bug or error found. It helps developers fix issues before they become problems in production."
# 	2. FIX any bugs or issues found with the code. The code is delimited by ++++++++++. ALSO, Suggest any improvements that can be made to the code.   Do not write anything about smart contracts unless the code is a smart contract.
# ] ++++++++++{msg}.++++++++++."""
#     )

#     prompt_template_goodpractice = PromptTemplate(
#         input_variables = ['msg'],
#         template = "Please analyze the blow codee and suggest good pratice: {msg}."
#     )

#     prompte_template_new_feature = PromptTemplate(
#         input_variables = ['msg'],
#         template = """ [follow the steps below in the order listed.  
#         1. Write "This output is to suggest new features that can be considered or added to your backlog to enhance the value of the application. 
#         2. Suggest 5 new features that can be added to this application if you believe the features may not exist.    The code is delimited by ++++++++++.  Do not write anything about smart contracts unless the code is a smart contract.
# ] ++++++++++ {msg}. ++++++++++."""
#     )


   


#     from langchain.chains import LLMChain

#     generated_text = []

#     chain = LLMChain(llm=llm, prompt=prompt_template_summary)
#     generated_text.append(chain.run(promptmsg))

#     chain = LLMChain(llm=llm, prompt=prompt_template_analyze)
#     generated_text.append(chain.run(promptmsg))

#     chain = LLMChain(llm=llm, prompt=prompt_template_goodpractice)
#     generated_text.append(chain.run(promptmsg))

#     chain = LLMChain(llm=llm, prompt=prompte_template_new_feature)
#     generated_text.append(chain.run(promptmsg))


#     print(generated_text)

#     return {"status": "success", "msg": generated_text}

@router.get("/change_url")
async def change_url(): 

    count = 0
    result =   BlogSummary_live.find({})
    if not result:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Something went wrong",
        )
    else:
        for rec in result:
            count += 1
            print(rec['url'])
            url = rec['url']
            url = re.sub(r'_','-',url)
            print('modified url.....')
            print(url)
            id = rec['_id']
            BlogSummary_live.update_one(
            {"_id": ObjectId(id)},
            {
                "$set": {
                    "url": url
                }
            },
        )
            
        print("\n")
    
    return {"status": "success", "count": count}

