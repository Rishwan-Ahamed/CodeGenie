from urllib import request
from fastapi import APIRouter, HTTPException, status, Response, Depends, Body
from datetime import datetime, timedelta
from random import randbytes
import hashlib
from typing import Annotated
import stripe
import random
from schemas.userSchemas import SocialSignupSchema, UserSignupSchema, UserSigninSchema, ForgotPasswordSchema, ResetPasswordSchema, FeebackSchema, ContactUsSchema, UpdatePasswordSchema, SubscribeSchema
from database import Users
from database import Subscribe
from database import Feedback
import utils
from emails.verifyEmail import Contactus, Feedbackemail, VerifyEmail, ForgotPassEmail, ResendVerificationEmail
from oauth2 import AuthJWT, require_user
from config import settings


router = APIRouter()

# Replace with your Stripe secret key
stripe.api_key = settings.STRIPE_SECRET_KEY



@router.post("/social")
async def social_signup(
    social_data: SocialSignupSchema, response: Response, Authorize: AuthJWT = Depends()
):
    
    existing = Users.find_one({"email": social_data.email,"provider":"normal"})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="User already exists with this email id as normal login, try normal login with email id and password."
        )

    if social_data.provider == "google":
        db_user = Users.find_one({"email": social_data.email})
    if social_data.provider == "github":
        db_user = Users.find_one(
            {"provider": "github", "username": social_data.id}
        )
    if social_data.provider == "facebook":
        db_user = Users.find_one(
            {"provider": "facebook", "email": social_data.id}
        )
    if social_data.provider == "twitter":
        db_user = Users.find_one(
            {"provider": "twitter", "email": social_data.id}
        )
    if social_data.provider == "linkedin":
        db_user = Users.find_one(
            {"provider": "linkedin", "email": social_data.id}
        )

    if not db_user:
        user_info = social_data.dict()
        user_info['email'] = social_data.email
        user_info["role"] = "user"
        user_info["verified"] = True
        user_info["status"] = "active"
        user_info["free_plan"] = 1
        user_info["created_at"] = datetime.utcnow()
        user_info["updated_at"] = user_info["created_at"]
        user_info["remaining_wish_count"] = 1
        user_info["total_wishes"] = 1
        user_info["used_wish_count"] = 0
        user_info["subscription_level"] = ""
        user_info["initial_product"] = social_data.initial_product
        result = Users.insert_one(user_info)
        db_user = Users.find_one({"_id": result.inserted_id})

    # Create access token 
    access_token = Authorize.create_access_token(
        subject=str(db_user["_id"]),
        expires_time=timedelta(minutes=ACCESS_TOKEN_EXPIRES_IN),
    )

    # Create refresh token
    refresh_token = Authorize.create_refresh_token(
        subject=str(db_user["_id"]),
        expires_time=timedelta(minutes=REFRESH_TOKEN_EXPIRES_IN),
    )

    response.set_cookie(
        key="access_token",
        value=access_token,
        max_age=ACCESS_TOKEN_EXPIRES_IN * 60,
        expires=ACCESS_TOKEN_EXPIRES_IN * 60,
        path="/",
        domain=None,
        secure=True,
        httponly=True,
        samesite="none",
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        max_age=REFRESH_TOKEN_EXPIRES_IN * 60,
        expires=REFRESH_TOKEN_EXPIRES_IN * 60,
        path="/",
        domain=None,
        secure=True,
        httponly=True,
        samesite="none",
    )
    response.set_cookie(
        key="logged_in",
        value="True",
        max_age=ACCESS_TOKEN_EXPIRES_IN * 60,
        expires=ACCESS_TOKEN_EXPIRES_IN * 60,
        path="/",
        domain=None,
        secure=True,
        httponly=True,
        samesite="none",
    )

    # Send both access
    return {
        "access_token": access_token,
        "role": db_user["role"],
        "free_plan": db_user["free_plan"],
        "remaining_wish_count": db_user["remaining_wish_count"],
        "subscription_level": db_user["subscription_level"]

    }


@router.post("/signup")
async def signup_user(payload: UserSignupSchema):
    if payload.password != payload.passwordConfirm:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Password doesn't match"
        )
    existing = Users.find_one({"email": payload.email})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="User already exists"
        )
    user_info = payload.dict()
    del user_info["passwordConfirm"]
    user_info["role"] = "user"
    user_info["verified"] = False
    user_info["status"] = "active"
    user_info["provider"] = "normal"
    user_info["username"] = None
    user_info["free_plan"] = 1
    user_info["remaining_wish_count"] = 1
    user_info["total_wishes"] = 1
    user_info["used_wish_count"] = 0
    user_info["created_at"] = datetime.utcnow()
    user_info["updated_at"] = user_info["created_at"]
    user_info["password"] = utils.hash_password(payload.password)
    user_info["subscription_level"] = ""
    user_info["initial_product"] = payload.initial_product
    result = Users.insert_one(user_info)
    new_user = Users.find_one({"_id": result.inserted_id})
    try:
        token = randbytes(10)
        hashedCode = hashlib.sha256()
        hashedCode.update(token)
        verification_code = hashedCode.hexdigest()
        Users.find_one_and_update(
            {"_id": result.inserted_id},
            {
                "$set": {
                    "verification_code": verification_code,
                    "updated_at": datetime.utcnow(),
                }
            },
        )
        print(token.hex())
        await VerifyEmail(
            new_user["name"], token.hex(), [payload.email]
        ).sendVerificationCode()
    except Exception as error:
        print(error)
        Users.find_one_and_update(
            {"_id": result.inserted_id},
            {"$set": {"verification_code": None, "updated_at": datetime.utcnow()}},
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="There was an error sending email",
        )
    return {
        "status": "success",
        "message": "Verification token successfully sent to your email",
    }


ACCESS_TOKEN_EXPIRES_IN = settings.ACCESS_TOKEN_EXPIRES_IN
REFRESH_TOKEN_EXPIRES_IN = settings.REFRESH_TOKEN_EXPIRES_IN




@router.post("/signin")
async def user_signin(
    payload: UserSigninSchema, response: Response, Authorize: AuthJWT = Depends(), client_ip: str=""
):
    # Check if the user exist
    db_user = Users.find_one({"email": payload.email})

    print("*****************")
    print(db_user)

    if not db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect Email",
        )
    

    # Check if the password is valid
   
    if not utils.verify_password(payload.password, db_user["password"]):
        #print("hashpassword::::"+payload.password+"--"+db_user["password"]+"\r\n\r\n")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect Password",
        )
    
    if(db_user["status"]=="inactive"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You account is not active, pls. contact administrator",
        )

    # Create access token
    access_token = Authorize.create_access_token(
        subject=str(db_user["_id"]),
        expires_time=timedelta(minutes=ACCESS_TOKEN_EXPIRES_IN),
    )

    # Create refresh token
    refresh_token = Authorize.create_refresh_token(
        subject=str(db_user["_id"]),
        expires_time=timedelta(minutes=REFRESH_TOKEN_EXPIRES_IN),
    )

    # Store refresh and access tokens in cookie
    response.set_cookie(
        key="access_token",
        value=access_token,
        max_age=ACCESS_TOKEN_EXPIRES_IN * 60,
        expires=ACCESS_TOKEN_EXPIRES_IN * 60,
        path="/",
        domain=None,
        secure=True,
        httponly=True,
        samesite="none",
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        max_age=REFRESH_TOKEN_EXPIRES_IN * 60,
        expires=REFRESH_TOKEN_EXPIRES_IN * 60,
        path="/",
        domain=None,
        secure=True,
        httponly=True,
        samesite="none",
    )
    response.set_cookie(
        key="logged_in",
        value="True",
        max_age=ACCESS_TOKEN_EXPIRES_IN * 60,
        expires=ACCESS_TOKEN_EXPIRES_IN * 60,
        path="/",
        domain=None,
        secure=True,
        httponly=True,
        samesite="none",
    )

    # Check if the user exist
    db_user = Users.find_one_and_update({"email": payload.email},{"$set":{"last_login":datetime.utcnow(),"client_ip":client_ip}})

    # Send both access
    return {
        "access_token": access_token,
        "role": db_user["role"],
        "verified": db_user["verified"],
        "free_plan": db_user["free_plan"],
        "remaining_wish_count": db_user["remaining_wish_count"],
        "subscription_level": db_user["subscription_level"],
        "initial_product": db_user["initial_product"],
        "user_email": db_user["email"]
    }


@router.patch("/verify")
async def verify_email(code: Annotated[str, Body(..., embed=True)]):
    hashedCode = hashlib.sha256()
    hashedCode.update(bytes.fromhex(code))
    verification_code = hashedCode.hexdigest()
    result = Users.find_one_and_update(
        {"verification_code": verification_code},
        {
            "$set": {
                "verification_code": None,
                "verified": True,
                "updated_at": datetime.utcnow(),
            }
        },
        new=True,
    )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid verification code",
        )
    return {"status": "success", "message": "Verified Successfully"}

@router.post("/forgotPass")
async def forgot_pass(payload: ForgotPasswordSchema):
    if payload.email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": payload.email})
    print(existing)
    if existing:
        try:
            token = randbytes(10)
            hashedCode = hashlib.sha256()
            hashedCode.update(token)
            verification_code = hashedCode.hexdigest()
            Users.find_one_and_update(
                {"email": payload.email},
                {
                    "$set": {
                        "verification_code": verification_code,
                        "updated_at": datetime.utcnow(),
                    }
                },
            )
            print(token.hex())
            await ForgotPassEmail(
                existing["name"], token.hex(), [payload.email]
            ).sendVerificationCode()
        except Exception as error:
            print(error)
            Users.find_one_and_update(
                {"email": payload.email},
                {"$set": {"verification_code": None, "updated_at": datetime.utcnow()}},
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error sending email",
            )
    return {
        "status": "success",
        "message": "Password reset code successfully sent to your email",
    }

@router.post("/resetPass")
async def reset_pass(payload: ResetPasswordSchema):
    if payload.password != payload.passwordConfirm:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Password doesn't match"
        )
    existing = Users.find_one({"email": payload.email})
    if existing:
        user_info = payload.dict()
        user_info["password"] = utils.hash_password(payload.password)
        try:
            Users.find_one_and_update(
                {"email": payload.email},
                {
                    "$set": {
                        "password": user_info["password"],
                        "updated_at": datetime.utcnow(),
                    }
                },
            )
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in reset password",
            )
    return {
        "status": "success",
        "message": "Password reset done successfully",
    }

@router.post("/updatePass")
async def reset_pass(payload: UpdatePasswordSchema):
    if len(payload.oldPassword.strip())<=0:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Old Password should not be empty"
        )
    elif len(payload.password.strip())<=0:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Password should not be empty"
        )
    elif payload.password != payload.passwordConfirm:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Password doesn't match"
        )
    existing = Users.find_one({"email": payload.email})
    if existing:
        user_info = payload.dict()

        if not utils.verify_password(payload.oldPassword, existing["password"]):
            raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid old password"
        )
        user_info["password"] = utils.hash_password(payload.password)
        try:
            Users.find_one_and_update(
                {"email": payload.email},
                {
                    "$set": {
                        "password": utils.hash_password(payload.password),
                        "updated_at": datetime.utcnow(),
                    }
                },
            )
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error in reset password",
            )
    return {
        "status": "success",
        "message": "Password updated successfully",
    }

@router.post("/contactus")
async def send_feedback(payload: ContactUsSchema):
    if payload.email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )

    try:
        # Feedback.insert_one(
        #     {"email": payload.email,
        #     "rating": payload.rating,
        #     "feedback": payload.feedback,
        #     "productname":payload.productname,
        #     "date":datetime.utcnow()},
        # )

        
        
        await Contactus(
            payload.name, payload.email, payload.phone, payload.subject, payload.message
        ).sendFeedback()
    except Exception as error:
        print(error)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="There was an error sending email",
        )
    return {
        "status": "success",
        "message": "Thanks for contacting us.",
    }


@router.post("/sendFeedback")
async def send_feedback(payload: FeebackSchema):
    if payload.email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Users.find_one({"email": payload.email})

    if existing:
        try:
            Feedback.insert_one(
                {"email": payload.email,
                "rating": payload.rating,
                "feedback": payload.feedback,
                "productname":payload.productname,
                "date":datetime.utcnow()},
            )
            
            await Feedbackemail(
                payload.email, payload.rating, payload.feedback,payload.productname
            ).sendFeedback()
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error sending email",
            )
    return {
        "status": "success",
        "message": "Thanks for your valuable feedbacK.",
    }


@router.post("/subscribefornews")
async def subscribe(payload: SubscribeSchema):
    if payload.email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    existing = Subscribe.find_one({"email": payload.email})

    if existing:

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Thank you. You are already susbcribed.",
        )
    else:
        try:
            Subscribe.insert_one(
                {"email": payload.email,
                "status": "active",
                "create_at": datetime.utcnow(),
                "updated_at":datetime.utcnow()},
            )
            
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error sending email",
            )
    return {
        "status": "success",
        "message": "Thanks for your subscribing to our newletter.",
    }


@router.post("/getUserDetails")
async def send_feedback(email: str):
    if email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"
        )
    

    #IF DATE available
      # Define the aggregation pipeline
    pipeline = [
        {
        '$match': {
                'email': email  # Filter based on the email_id
            }
        },
        {
            '$lookup': {
                'from': 'products',  # The name of the second collection
                'localField': 'planDetails.price_id',  # The field in the current collection to match
                'foreignField': 'price_id',  # The field in the second collection to match
                'as': 'joinedData'  # The name of the output array field
            }
        },
        {
            '$project': {
                '_id': 0,  # Exclude the _id field
                'email': 1,  # Include other fields you want in the result
                'subscription_date': 1,
                'price_id':1,
                'matchedPlanDetails': {
                    '$filter': {
                        'input': '$joinedData',
                        'as': 'joinedDoc',
                        'cond': {
                            '$eq': ['$$joinedDoc.price_id', '$planDetails.price_id']
                        }
                    }
                }
            },
             
        },

        {
            '$project': {
                'joinedData._id': 0,  # Exclude _id field from the Products collection
                'joinedData.planDetails._id': 0,  # Exclude _id field from the planDetails subdocument
                 'matchedPlanDetails': {
                    '_id': 0,  # Exclude _id field from the planDetails subdocument
                }
            }
            
        }
    ]


    #existing = Users.find_one({"email": email},{"_id":0})
    existing = list(Users.aggregate(pipeline))

    userdet = existing[0]


     # Check if there are any results
    if not existing:
        return {
            "status": "success",
            "message": "No user details found for the provided email.",
            "userdet": []  # Return an empty list
        }

        
    return {
        "status": "success",
        "message": "User detail returned successfully.",
        "userdet": userdet
    }
   
    


@router.post("/getUserList")
async def get_user_list(skip: int = 0, limit: int = 10,from_date: str="", to_date: str="",search_str: str="",product: str=""):

    #if dates exists
    fromDate = datetime.now().strftime("%Y-%m-%d")
    toDate = datetime.now().strftime("%Y-%m-%d")
    if from_date!="":
        fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    if to_date!="":
        toDate = datetime.strptime(to_date, "%Y-%m-%d")

    filter = {"$and": [{"role": "user"}]}
    if (from_date!="" and to_date!="" and search_str!=""):
        # Define the regular expression pattern
        regex_pattern = re.compile(f"^{search_str}", re.IGNORECASE)  # Matches strings that start with "abc" (case-insensitive)
        filter = {"$and":[{"created_at": {"$gte": fromDate, "$lte":toDate}},{"$or":[{"name":{"$regex":regex_pattern}},{"email":{"$regex":regex_pattern}},{"new_product_module":{"$regex":regex_pattern}}]},{"role":"user"}]}
    if (from_date!="" and to_date!="" and search_str==""):
        filter = {"$and":[{"created_at": {"$gte": fromDate, "$lte":toDate}},{"role":"user"}]}
    if ((from_date=="" or to_date=="") and search_str!=""):
        regex_pattern = re.compile(f"^{search_str}", re.IGNORECASE)  # Matches strings that start with "abc" (case-insensitive)
        filter = {"$and":[{"$or":[{"name":{"$regex":regex_pattern}},{"email":{"$regex":regex_pattern}},{"new_product_module":{"$regex":regex_pattern}}]},{"role":"user"}]}

    if(product!=""):
        extrafilter = {"$or":[{"product_module":product},{"initial_product":product}]}
        filter["$and"].append(extrafilter)


    existing = Users.find(filter,{"_id":0}).sort('created_at', -1).skip(skip).limit(limit)

    recordcount = Users.count_documents(filter)

    userdet = []

   
    if existing:
        try:
            userdet = list(existing)
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error getting user list",
            )
    return {
        "status": "success",
        "message": "User list returned successfully.",
        "userdet": userdet,
        "totalrecords": recordcount
    }

@router.post("/getSubscribers")
async def get_subscriber_list(skip: int = 0, limit: int = 10,from_date: str="", to_date: str="",search_str: str=""):

    #if dates exists
    fromDate = datetime.now().strftime("%Y-%m-%d")
    toDate = datetime.now().strftime("%Y-%m-%d")
    if from_date!="":
        fromDate = datetime.strptime(from_date, "%Y-%m-%d")
    if to_date!="":
        toDate = datetime.strptime(to_date, "%Y-%m-%d")

    if (from_date!="" and to_date!="" and search_str!=""):
        # Define the regular expression pattern
        regex_pattern = re.compile(f"^{search_str}", re.IGNORECASE)  # Matches strings that start with "abc" (case-insensitive)
        filter = {"$and":[{"created_at": {"$gte": fromDate, "$lte":toDate}},{"email":{"$regex":regex_pattern}}]}
    if (from_date!="" and to_date!="" and search_str==""):
        filter = {"$and":[{"created_at": {"$gte": fromDate, "$lte":toDate}}]}
    if ((from_date=="" or to_date=="") and search_str!=""):
        regex_pattern = re.compile(f"^{search_str}", re.IGNORECASE)  # Matches strings that start with "abc" (case-insensitive)
        filter = {"email":{"$regex":regex_pattern}}
    if (from_date=="" and to_date=="" and search_str==""):
        filter = {}

    print(filter)

    existing = Subscribe.find(filter,{"_id":0}).sort('created_at', -1).skip(skip).limit(limit)

    recordcount = Subscribe.count_documents(filter)

    userdet = []

   
    if existing:
        try:
            userdet = list(existing)
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error sending email",
            )
    return {
        "status": "success",
        "message": "User list returned successfully.",
        "userdet": userdet,
        "totalrecords": recordcount
    }

@router.get("/delete_subscriber")
async def delete_subscriber(email: str):
    result = Subscribe.delete_one(
        {"email": email}
    )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid email id",
        )
    return {"status": "success", "message": "Subscriber deleted Successfully"}

@router.post("/resend_code")
async def resend_code(payload: ForgotPasswordSchema):
    if payload.email == "":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email"    
        )
    existing = Users.find_one({"email": payload.email})
    if existing:
        try:
            token = random.randbytes(10)
            hashedCode = hashlib.sha256()
            hashedCode.update(token)
            verification_code = hashedCode.hexdigest()
            Users.find_one_and_update(
                {"email": payload.email},
                {
                    "$set": {
                        "verification_code": verification_code,
                        "updated_at": datetime.utcnow(),
                    }
                },
            )
            print(token.hex())
            await ResendVerificationEmail(
                existing["name"], token.hex(), [payload.email],
            ).sendVerificationCode()
        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="There was an error sending email",
            )
        return {"status": "success", "message": "New Verification Code successfully sent to your email."}
    else:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Email")




@router.get("/activate_user")
async def activate_user(email: str):
    result = Users.find_one_and_update(
        {"email": email},
        {
            "$set": {
                "status": "active",
                "verified": True,
                "updated_at": datetime.utcnow(),
            }
        }
    )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid verification code",
        )
    return {"status": "success", "message": "Activated Successfully"}

@router.get("/deactivate_user")
async def activate_user(email: str):
    result = Users.find_one_and_update(
        {"email": email},
        {
            "$set": {
                "status": "inactive",
                "verified": True,
                "updated_at": datetime.utcnow(),
            }
        }
    )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid verification code",
        )
    return {"status": "success", "message": "Deactivated Successfully"}

@router.get("/subscribe")
async def activate_user(email: str):
    result = Users.find_one_and_update(
        {"email": email},
        {
            "$set": {
                "status": "inactive",
                "verified": True,
                "updated_at": datetime.utcnow(),
            }
        }
    )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid verification code",
        )
    return {"status": "success", "message": "Deactivated Successfully"}

"""
@router.post("/create-payment-intent")
async def create_paument_intent():
    try:
        data = request.json
        payment_method_type = data["paymentMethodType"]
        currency = data["currency"]

        payment_intent = stripe.PaymentIntent.create(
            amount = 100,
            currency= currency,
            payment_methos_types=[payment_method_type]
        )
        return {"status": "success", "client_secret": payment_intent.client_secret}
    except stripe.error.StripeError as e:
        return {"status": "error", "client_secret": e.user_message}, 400
    except Exception as e:
        return {"status": "error", "client_secret": e.user_message}, 500
    

@router.post("/process-payment/")
async def process_payment(amount: int, currency: str, token: str):
    try:
        # Create a charge using the Stripe API
        charge = stripe.Charge.create(
            amount=amount,
            currency=currency,
            source=token,  # Stripe token obtained from the client-side (e.g., Stripe.js)
            description="Payment for FastAPI Store",  # Add a description for the payment
        )

        # You can handle the charge object as per your requirements
        # For example, log the payment or perform other actions

        # Return a success response
        return {"status": "success", "charge_id": charge.id}

    except stripe.error.CardError as e:
        # Handle specific Stripe errors
        return {"status": "error", "message": str(e)}
    except stripe.error.StripeError as e:
        # Handle generic Stripe errors
        return {"status": "error", "message": "Something went wrong. Please try again later."}
"""